package com.acme.cashmachine.model;

import java.sql.Connection;

public class OrderVm {
	private int ownCode;       
	private int refDocOwnCode;	
	private int locCode2; 
	private int personCode; 
	private String memoType; 
	private int documentMasterCode;
	private String documentSeries;
	private int DocumentMasterCodeForNextTransaction4;
	private int documentNo;
	private int masterCodeForNewDmnRecord;
	private Connection DbConnection;
	private int advanceAmount;
	private int installmentNo;
	private int schemeCode;
	private String docDate;

	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	public int getSchemeCode() {
		return schemeCode;
	}
	public void setSchemeCode(int schemeCode) {
		this.schemeCode = schemeCode;
	}
	public int getInstallmentNo() {
		return installmentNo;
	}
	public void setInstallmentNo(int installmentNo) {
		this.installmentNo = installmentNo;
	}
	public int getAdvanceAmount() {
		return advanceAmount;
	}
	public void setAdvanceAmount(int advanceAmount) {
		this.advanceAmount = advanceAmount;
	}
	public Connection getDbConnection() {
		return DbConnection;
	}
	public void setDbConnection(Connection dbConnection) {
		DbConnection = dbConnection;
	}
	public int getMasterCodeForNewDmnRecord() {
		return masterCodeForNewDmnRecord;
	}
	public void setMasterCodeForNewDmnRecord(int masterCodeForNewDmnRecord) {
		this.masterCodeForNewDmnRecord = masterCodeForNewDmnRecord;
	}
	public int getDocumentNo() {
		return documentNo;
	}
	public void setDocumentNo(int documentNo) {
		this.documentNo = documentNo;
	}
	public int getDocumentMasterCodeForNextTransaction4() {
		return DocumentMasterCodeForNextTransaction4;
	}
	public void setDocumentMasterCodeForNextTransaction4(
			int documentMasterCodeForNextTransaction4) {
		DocumentMasterCodeForNextTransaction4 = documentMasterCodeForNextTransaction4;
	}
	public String getDocumentSeries() {
		return documentSeries;
	}
	public void setDocumentSeries(String documentSeries) {
		this.documentSeries = documentSeries;
	}
	public int getOwnCode() {
		return ownCode;
	}
	public void setOwnCode(int ownCode) {
		this.ownCode = ownCode;
	}
	public int getRefDocOwnCode() {
		return refDocOwnCode;
	}
	public void setRefDocOwnCode(int refDocOwnCode) {
		this.refDocOwnCode = refDocOwnCode;
	}
	public int getLocCode2() {
		return locCode2;
	}
	public void setLocCode2(int locCode2) {
		this.locCode2 = locCode2;
	}
	public int getPersonCode() {
		return personCode;
	}
	public void setPersonCode(int personCode) {
		this.personCode = personCode;
	}
	public String getMemoType() {
		return memoType;
	}
	public void setMemoType(String memoType) {
		this.memoType = memoType;
	}
	public int getDocumentMasterCode() {
		return documentMasterCode;
	}
	public void setDocumentMasterCode(int documentMasterCode) {
		this.documentMasterCode = documentMasterCode;
	}
	
}
