/*-
 *  File    :   SchemeDataViewModel.java
 *  Version :   1.0
 *  Date    :   Mar 6, 2016
 *  Author  :   Monika
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;



/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class SchemeDataViewModel {

	/**
	 * Represents total metal against order
	 */
	private BigDecimal totalMetal;
	/**
	 * Represents total advance against order
	 */
	private BigDecimal totalAdvance;
	private BigDecimal totalTaxOnAdvance;

	private BigDecimal totalInstallmentAmount;
	// Added by varsha
	private BigDecimal totalTax;
	/**
	 * Repersents Scheme Details
	 */
	private SchemeDetailsViewModel schemeDetails;

	/**
	 * Represents scheme Order Details
	 */
	private List<SchemeOrderDetailsModel> schemeOrderDetailsModel = new ArrayList<SchemeOrderDetailsModel>();
	private BigDecimal totalMetalBooked;

	/**
	 *
	 */
	public SchemeDataViewModel() {
		totalMetalBooked = BigDecimal.ZERO;
	}

	/**
	 * @return the totalMetalBooked
	 */
	public BigDecimal getTotalMetalBooked() {
		return totalMetalBooked;
	}

	/**
	 * @param totalMetalBooked
	 *            the totalMetalBooked to set
	 */
	public void setTotalMetalBooked(BigDecimal totalMetalBooked) {
		this.totalMetalBooked = totalMetalBooked;
	}

	public BigDecimal getTotalTaxOnAdvance() {
		return totalTaxOnAdvance;
	}

	public void setTotalTaxOnAdvance(BigDecimal totalTaxOnAdvance) {
		this.totalTaxOnAdvance = totalTaxOnAdvance;
	}

	/**
	 * Represents scheme order details which are eligible to return
	 */
	private List<SchemeOrderDetailsModel> schemeEligibleToReturn = new ArrayList<SchemeOrderDetailsModel>();
	/**
	 * Represents total PDC count against Scheme Order
	 */
	private int pdcCount;

	public List<SchemeOrderDetailsModel> getSchemeOrderDetailsModel() {
		return schemeOrderDetailsModel;
	}

	/**
	 *
	 * @param schemeOrderDetailsModel
	 */
	public void setSchemeOrderDetailsModel(
			List<SchemeOrderDetailsModel> schemeOrderDetailsModel) {
		this.schemeOrderDetailsModel = schemeOrderDetailsModel;
	}

	public SchemeDetailsViewModel getSchemeDetails() {
		return schemeDetails;
	}

	public void setSchemeDetails(SchemeDetailsViewModel schemeDetails) {
		this.schemeDetails = schemeDetails;
	}

	public List<SchemeOrderDetailsModel> getSchemeEligibleToReturn() {
		return schemeEligibleToReturn;
	}

	public void setSchemeEligibleToReturn(
			List<SchemeOrderDetailsModel> schemeEligibleToReturn) {
		this.schemeEligibleToReturn = schemeEligibleToReturn;
	}

	public BigDecimal getTotalMetal() {
		return totalMetal;
	}

	public void setTotalMetal(BigDecimal totalMetal) {
		this.totalMetal = totalMetal;
	}

	public BigDecimal getTotalAdvance() {
		return totalAdvance;
	}

	public void setTotalAdvance(BigDecimal totalAdvance) {
		this.totalAdvance = totalAdvance;
	}

	public int getPdcCount() {
		return pdcCount;
	}

	public void setPdcCount(int pdcCount) {
		this.pdcCount = pdcCount;
	}

	public BigDecimal getTotalInstallmentAmount() {
		return totalInstallmentAmount;
	}

	public void setTotalInstallmentAmount(BigDecimal totalInstallmentAmount) {
		this.totalInstallmentAmount = totalInstallmentAmount;
	}

	public BigDecimal getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(BigDecimal totalTax) {
		this.totalTax = totalTax;
	}

}
