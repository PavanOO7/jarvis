package com.acme.cashmachine;

import com.acme.cashmachine.model.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acme.cashmachine.model.CustomerDetailsViewModel;
import com.acme.cashmachine.model.CustomerSchemeOutputVm;
import com.acme.cashmachine.model.DatabaseConnectionService;
import com.acme.cashmachine.model.OrderComponentMainViewModel;
import com.acme.cashmachine.model.OrderDataViewModel;
import com.acme.cashmachine.model.OrderDetailViewModel;
import com.acme.cashmachine.model.SchemeDataViewModel;
import com.acme.cashmachine.model.SchemeDetailsViewModel;
import com.acme.cashmachine.model.SchemeOperationVm;
import com.acme.cashmachine.model.customrDetailsViewModel;
import com.fasterxml.jackson.databind.util.JSONPObject;

@RestController
public class GetOrderDetailsController 
{
	
	private DatabaseConnectionService databaseConnectionService;
	private GetDataFromDBService getDataFromDbService;
	private GetDataFromDbForGetOrderDetailsController getDataFromDbForGetOrderDetailsController;
	
	@Autowired
	public GetOrderDetailsController(DatabaseConnectionService databaseConnectionService,GetDataFromDBService getDataFromDbService,
			GetDataFromDbForGetOrderDetailsController getDataFromDbForGetOrderDetailsController)
	{
		this.databaseConnectionService = databaseConnectionService;
		this.getDataFromDbService      = getDataFromDbService;
		this.getDataFromDbForGetOrderDetailsController = getDataFromDbForGetOrderDetailsController;
	}
	@RequestMapping(value = "/scm/v1/scheme/2", method = RequestMethod.POST)
	public SchemeOperationVm getOrderDetails(
			@RequestBody String  orderNo) throws Exception 
	{				  
	
		//DownloadPdfFromServer DownloadPdfFromServer=new DownloadPdfFromServer();
		//DownloadPdfFromServer.downloadPdfFromServer("172.16.2.114", "vrm", "vrm");
		//System.out.println(orderNo);
	
      // Connection con = databaseConnectionService.databaseConnectionMethod();
		
	/*Connection con = null;
		BufferedReader br =null;
		ClassLoader classLoader = getClass().getClassLoader();
		  File file = new File(classLoader.getResource("\\Web-config.txt").getFile());
		  Class.forName("com.mysql.jdbc.Driver");
  	  String textData = null;
		 // File file = new File("C:\\AcmeTmpFiles\\Web-config.txt");		 
		  br = new BufferedReader(new FileReader(file));		 			 
		  while ((textData = br.readLine()) != null)
			  
	      //
			  try{
		  con = DriverManager.getConnection(textData,"AcmeInfi","ProteasLankans");
				  CustomerSchemeOutputVm customer = new CustomerSchemeOutputVm();	
				  customer.setErrorCode(1001);
				  customer.setErrorMsg(textData);
				  customer.setResult(null);
					SchemeOperationVm vm1 = new SchemeOperationVm();
					vm1.setData(customer);
					return vm1;  
			  }catch(Exception e){
				  con = DriverManager.getConnection(textData,"AcmeInfi","ProteasLankans");
				  CustomerSchemeOutputVm customer = new CustomerSchemeOutputVm();	
				  customer.setErrorCode(1001);
				  customer.setErrorMsg(textData);
				  customer.setResult(null);
					SchemeOperationVm vm1 = new SchemeOperationVm();
					vm1.setData(customer);
					return vm1;
			  }*/
     //  System.out.println("abc >> "+con);  
       Connection con1=null;
       Class.forName("com.mysql.jdbc.Driver");
       con1 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
    	
    	
    	if(con1==null || con1.equals(""))
		{
			CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
			customerVm1.setErrorCode(1001);
			customerVm1.setErrorMsg(" Cannot Connect to Database.");
			customerVm1.setResult(null);
			SchemeOperationVm vm = new SchemeOperationVm();
			vm.setData(customerVm1);
			return vm;
		}	
    	
        //System.out.println("abc >> "+con);
        customrDetailsViewModel customerVm = new customrDetailsViewModel();
        SchemeDetailsViewModel schemeDetails = new SchemeDetailsViewModel();
    	String docNo,custName,address1,address2,panNo,area,city,phoneNo,pinCode;
		String docSeries,series = null,memoType = null;
		 int documentNo=0,docMasterCode=0,ownCode=0,isCompleteFlag=0,installmentNo = 0;
		 String docDate=null;
		 int personCode=0,refDocOwnCode=0,advanceAmount=0,adjustmentMethod=0;
		 int documentTypeCode=0,documentMasterCode=0,locationCode1=0,locationCode2=0;
		 String dueDate=null;
		 int doc1;
		 		 
		 JSONObject obj1=new JSONObject(orderNo);			   
		 String Order1 = String.valueOf(obj1);
		 if (!Order1.matches(".*\\d+.*"))
		   {
			    CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
 				customerVm1.setErrorCode(1001);
 				customerVm1.setErrorMsg(" Invalid Order No ");
 				customerVm1.setResult(null);
 				SchemeOperationVm vm = new SchemeOperationVm();
 				vm.setData(customerVm1);
 				return vm;
		   }
		 
		try{				
			   
		       Class.forName("com.mysql.jdbc.Driver");
		       Connection con11=null;
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			   String JSONString=null,loc=null;		
			   Class.forName("com.mysql.jdbc.Driver");	   			     			 
   			   JSONObject obj=new JSONObject(orderNo);
   			   List<String> seriesDocNoList= new ArrayList<>();
   			   String Order = String.valueOf(obj);
   			   String series1 =  obj.get("orderNo").toString().replaceAll("[^a-z || A-Z]", "").trim();//numbers2.trim();//seriesDocNoList.get(0);			   
			   doc1 = Integer.parseInt(obj.get("orderNo").toString().replaceAll("[^0-9]", "").trim());
				
			   if(series1==null || series1.equals("") || doc1 == 0)
		   			{
		   				CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
		   				customerVm1.setErrorCode(1001);
		   				customerVm1.setErrorMsg(" Invalid Order No ");
		   				customerVm1.setResult(null);
		   				SchemeOperationVm vm = new SchemeOperationVm();
		   				vm.setData(customerVm1);
		   				return vm;
		   			}
			   
   			   java.sql.Statement stmt1=con11.createStatement();   			   
   			   ResultSet rs;    	    
   			   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE COMPCODE=1 AND DOCUMENTTYPECODE=6 AND DOCUMENTSUBTYPE = 'B' AND DOCNO="+doc1+" AND SERIES ='"+series1+"'");
			   			
   			   	try
   			   		{
   			   			while(rs.next())
   			   				{
   			   					series             =  rs.getString("series");
   			   					documentNo         =  rs.getInt("docNo");
   			   					docMasterCode      =  rs.getInt("documentMasterCode"); 
   			   					ownCode            =  rs.getInt("ownCode"); 
   			   					memoType		   =  rs.getString("memoType");		
   			   					docDate 	       =  String.valueOf(rs.getInt("docDate"));
   			   					int docDate1 = Integer.parseInt(docDate);
   			   				     docDate = getDdMmYyDate(docDate1);
   			   					personCode  	   =  rs.getInt("personCode"); 
   			   					refDocOwnCode      =  rs.getInt("refDocOwnCode"); 
   			   					advanceAmount      =  rs.getInt("advanceAmount");
   			   					adjustmentMethod   =  rs.getInt("adjustmentMethod");
   			   					documentTypeCode   =  rs.getInt("documentTypeCode");
   			   					documentMasterCode =  rs.getInt("documentMasterCode");
   			   					dueDate  		   =  String.valueOf(rs.getInt("dueDate"));
   			   			    	int docDate2 = Integer.parseUnsignedInt(dueDate);
   			   			        dueDate = getDdMmYyDate(docDate2);   			   				    
   			   					locationCode1 	   =  rs.getInt("locationCode1");
   			   					locationCode2 	   =  rs.getInt("locationCode2");    
   			   					isCompleteFlag     =  rs.getInt("isComplete");   			   				    
   			   				 }
                       
   			   			if(series==null || series.equals(""))
   			   			{
   			   				CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
   			   				customerVm1.setErrorCode(1001);
   			   				customerVm1.setErrorMsg(obj.get("orderNo").toString()+" Invalid Order No ");
   			   				customerVm1.setResult(null);
   			   				SchemeOperationVm vm = new SchemeOperationVm();
   			   				vm.setData(customerVm1);
   			   				return vm;
   			   			}
   			   			
   			   		installmentNo = getDataFromDbService.installmentNumber(ownCode,advanceAmount);
   			   		schemeDetails = getSchemeData(adjustmentMethod,memoType);
   			   	
   			   		customerVm    = getCustomerDetails(personCode);
   			   			 	
   			   		}
     catch(Exception e)
     {
    	 System.out.println(e);
     }
	     
	 }
		
	catch(Exception e)
		{
			throw new Exception("Provided Order is invalid : "+e.getMessage());		
		}
		
		SchemeDataViewModel SchemeData=new SchemeDataViewModel();
		
	    //................SchemeOrderDetailsModel..................
		//SchemeOrderDetailsModel schemeOrderDetailsModel = new SchemeOrderDetailsModel();
		List<SchemeOrderDetailsModel> schemeOrderDetailsList = new ArrayList<SchemeOrderDetailsModel>();
		//schemeOrderDetailsModel  = getDataFromDbForGetOrderDetailsController.getSchemeOrderDetails(ownCode);
		schemeOrderDetailsList  = getDataFromDbForGetOrderDetailsController.getSchemeOrderDetails(ownCode);
		//schemeOrderDetailsList.add(schemeOrderDetailsModel);
		//schemeOrderDetailsList.add(schemeOrderDetailsModel);
		SchemeData.setSchemeOrderDetailsModel(schemeOrderDetailsList);
		//................SchemeOrderDetailsModel..................
		//SchemeDetailsViewModel schemeDetails = new SchemeDetailsViewModel();
		
		SchemeData.setSchemeDetails(schemeDetails);
		//OrderDataViewModel orderDataVm=new OrderDataViewModel();	
		
		CustomerDetailsViewModel cust=new CustomerDetailsViewModel();
		int branchCode=getBranchCode(ownCode);   
		OrderComponentMainViewModel orderVm = new OrderComponentMainViewModel();		
		cust.setName(customerVm.getCustomerName().trim());
		cust.setAddressLine1(customerVm.getAddress1().trim());
		cust.setAddressLine2(customerVm.getAddress2().trim());
		cust.setMobileNo(customerVm.getMobileNo());
		cust.setCode(customerVm.getCustomerMasterCode());
		cust.setPanNo(customerVm.getPanNo());
		cust.setArea(customerVm.getArea());
		cust.setCity(customerVm.getCity());
		cust.setPhoneNo(String.valueOf(customerVm.getPhoneNo()));
		cust.setPinCode(String.valueOf(customerVm.getPincode()));
		
		orderVm.setCustomerDetailsViewModel(cust);
		orderVm.setSchemeDataViewModel(SchemeData);
		//orderVm.setOrderDataViewModel(orderDataVm);
		
		CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
		customerVm1.setResult(orderVm);
		orderVm.setDate(docDate);	
		//**************************
		
		//**************************
		/*Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(docDate);  
		DateFormat df1 = new SimpleDateFormat("dd/MM/yy");
		Date formattedDate1 = df1.parse(docDate);
		System.out.println("   d1 :: "+df1.format(formattedDate1));*/
		
		orderVm.setOwnCode(ownCode);
		orderVm.setCustomerCode(personCode);
		orderVm.setMaturityDate(dueDate);
		orderVm.setMaxInstallmentDateAllowed(dueDate);
		
		//**************************
	  //SchemeDataViewModel schemeDataViewModel = new SchemeDataViewModel();
		orderVm.setSchemeDataViewModel(SchemeData);
		BigDecimal totalInstallmentAmount =  getDataFromDbService.getInstallmentAmount(ownCode);
		//System.out.println("totalInstallmentAmount :: "+totalInstallmentAmount);
		SchemeData.setTotalInstallmentAmount(totalInstallmentAmount);
		//**************************
		//DateFormat df2 = new SimpleDateFormat("dd/MM/yy");
		/*Date formattedDate2 = df1.parse(dueDate);
		
		if(formattedDate1.compareTo(formattedDate2) > 0)
		{
			//CustomerSchemeOutputVm customerVm1 = new CustomerSchemeOutputVm();	
			customerVm1.setErrorCode(1001);
			customerVm1.setErrorMsg("Document Date is greater then mautrity date.");
			customerVm1.setResult(null);
			SchemeOperationVm vm = new SchemeOperationVm();
			vm.setData(customerVm1);
			return vm;
		}	*/
		
		orderVm.setVoucherNo(series+"-"+doc1);
		orderVm.setBranchCode(branchCode);
		int scmCode = (int) schemeDetails.getSchemeCode();
		
		Map<String, Object> allowVariableInstallmntAmountMapResult = getDataFromDbService.allowVariableInstallmntAmount(scmCode);
		String variableAmt = (String) allowVariableInstallmntAmountMapResult.get("variableInstallmnt");
		//System.out.println("memo ::: "+variableAmt);
		if (variableAmt.contains("Yes"))
		{
			int installmentNo1 = getDataFromDbService.getInstallmentCount(ownCode);
			orderVm.setTotalInstallmentPaid(installmentNo1);
			//System.out.println("installmentNo1 :"+installmentNo1);
		}
		else
		{
			orderVm.setTotalInstallmentPaid(installmentNo);
			//System.out.println("installmentNo :"+installmentNo);
		}
		
		
		if (isCompleteFlag == 2)
		{
			orderVm.setStatusMessage("Order is Completed");
			orderVm.setStatusCode(200);
		}
		else
		{
			orderVm.setStatusMessage("Order is pending");
		}
		SchemeOperationVm vm = new SchemeOperationVm();
		vm.setData(customerVm1);
		return vm;
	}
	
	public void getOrderDetails(int orderNo) throws ClassNotFoundException, SQLException
	{
		 int documentNo=0,docMasterCode=0,ownCode=0,locationCode2=0;
		String docDate=null;
		 int personCode=0,refDocOwnCode=0,advanceAmount=0,adjustmentMethod=0;
		 int documentTypeCode=0,documentMasterCode=0,locationCode1=0;
		String dueDate=null;
	       Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

           Connection con = databaseConnectionService.databaseConnectionMethod();
          // Connection con = null;
		   JSONObject obj=new JSONObject(orderNo);
		   List<String> seriesDocNoList= new ArrayList<String>();
		   seriesDocNoList.addAll(Arrays.asList(obj.get("orderNo").toString().split("-")));
		   String series = seriesDocNoList.get(0);
		   String docNo = seriesDocNoList.get(1);
		   docNo  =  docNo.trim();
		   int doc = Integer.parseInt(docNo);	
		   java.sql.Statement stmt1=con11.createStatement();
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE COMPCODE=1 AND DOCUMENTTYPECODE=6 AND DOCUMENTSUBTYPE = 'B' AND DOCNO="+doc+" AND SERIES ='"+series+"'");
		   try
		   {
	    	 while(rs.next())
	    	 {
	    		  series             =  rs.getString("series");
	    		  documentNo         =  rs.getInt("docNo");
	    		  docMasterCode      =  rs.getInt("documentMasterCode"); 
	    		  ownCode            =  rs.getInt("ownCode"); 
	    		  docDate 	         =  String.valueOf(rs.getInt("docDate"));
	    		  int docDate1 = Integer.parseInt(docDate);
	    		  docDate = getDdMmYyDate(docDate1);
	    		  personCode  	     =  rs.getInt("personCode"); 
	    		  refDocOwnCode      =  rs.getInt("refDocOwnCode"); 
	    		  advanceAmount      =  rs.getInt("advanceAmount");
	    		  adjustmentMethod   =  rs.getInt("adjustmentMethod");
	    		  documentTypeCode   =  rs.getInt("documentTypeCode");
	    		  documentMasterCode =  rs.getInt("documentMasterCode");
	    		  dueDate  		     =  String.valueOf(rs.getInt("dueDate"));
	    		  int docDate2 = Integer.parseInt(dueDate);
	    		  dueDate = getDdMmYyDate(docDate2);
	    		  locationCode1 	 =  rs.getInt("locationCode1");
	    		  locationCode2 	 =  rs.getInt("locationCode2");
	    	 }	
	    	 
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
	}
	
	public customrDetailsViewModel getCustomerDetails(int personCode) throws ClassNotFoundException, SQLException
	{
		   customrDetailsViewModel customerModel = new customrDetailsViewModel();
	       Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

         //Connection con = databaseConnectionService.databaseConnectionMethod();
		 //Connection con = null;
		 java.sql.Statement stmt2=con11.createStatement();
		 ResultSet rs2;    	    
		 rs2=stmt2.executeQuery("SELECT  IFNULL(a.description,'')as name, IFNULL(a.mastercode,'') AS MasterCode,IFNULL(c.fieldvalue,'') AS Address1,IFNULL(d.fieldvalue,'') AS Address2,IFNULL(e.fieldvalue,'') AS PanNo,IFNULL(g.fieldvalue,'') AS City,IFNULL(h.fieldvalue,'') AS AREA,IFNULL(j.fieldvalue,'') AS PhoneNo,IFNULL(K.fieldvalue ,'') AS PinCode,IFNULL(l.fieldvalue ,'') AS MobileNo FROM PrimeMasters a  LEFT JOIN PrimeMasterDetails c ON a.CompCode=c.CompCode AND a.masterType=c.masterType AND c.fieldno=40 AND a.mastercode=c.mastercode  LEFT JOIN PrimeMasterDetails d ON a.CompCode=d.CompCode AND a.masterType=d.masterType AND d.fieldno=50 AND a.mastercode=d.mastercode  LEFT JOIN PrimeMasterDetails e ON a.CompCode=e.CompCode AND a.masterType=e.masterType AND e.fieldno=200 AND a.mastercode=e.mastercode  LEFT JOIN PrimeMasterDetails j ON  a.CompCode=j.CompCode  AND a.masterType=j.masterType AND j.fieldno=80 AND a.mastercode=j.mastercode  LEFT JOIN PrimeMasterDetails K ON a.CompCode=K.CompCode AND a.masterType=K.masterType AND K.fieldno=70 AND a.mastercode=K.mastercode  LEFT JOIN PrimeMasterDetails i ON  a.CompCode=i.CompCode   AND a.masterType=i.masterType AND i.fieldno=60 AND a.mastercode=i.mastercode LEFT JOIN PrimeMasterDetails l ON  a.CompCode=l.CompCode   AND a.masterType=l.masterType AND l.fieldno=90 AND a.mastercode=l.mastercode  LEFT JOIN SecondaryMasterDetails h ON i.FieldValue = h.MasterCode AND h.Mastertype = 16  AND h.FieldNo = 10  LEFT JOIN SecondaryMasterDetails g ON g.parentMasterCode = h.MasterCode AND g.Mastertype = 19  AND g.FieldNo = 10    WHERE a.mastercode="+personCode+" AND a.mastertype=7 AND a.compcode=1");
		
		 try
		 {
		   while(rs2.next())
      	    {			   
			   customerModel.setCustomerName(rs2.getString("name"));			   
			   customerModel.setArea(rs2.getString("City"));
			   customerModel.setCity(rs2.getString("Area"));
			   customerModel.setMobileNo(rs2.getLong("MobileNo"));
			   customerModel.setAddress1(rs2.getString("Address1"));
			   customerModel.setAddress2(rs2.getString("Address2"));
			   customerModel.setPanNo(rs2.getString("PanNo"));
			   customerModel.setCustomerMasterCode(rs2.getInt("MasterCode"));
			   customerModel.setPhoneNo(rs2.getLong("PhoneNo"));
			   customerModel.setPincode(Integer.valueOf(rs2.getString("PinCode")));          		
      	    }
		 }
		 catch(Exception e)
		 {
		  	 System.out.println(e);
		 }
		 con11.close();
		return customerModel;
	}
	
	public int getBranchCode(int ownCode) throws ClassNotFoundException, SQLException 
	{
		int branchCode=0;
		DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
        Connection con = databaseConnectionService.databaseConnectionMethod();
	       Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   //Class.forName("com.mysql.jdbc.Driver");
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/PngSons_15March","AcmeInfi","ProteasLankans");	
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT b.FieldValue FROM DocumentMainTable a JOIN SecondaryMasterDetails b ON a.compCode=b.CompCode AND b.mastertype=10 AND b.mastercode=a.locationcode2 AND b.fieldno=30 WHERE a.COMPCODE=1 AND a.OwnCode="+ownCode+"");
		   try
		   {
			while(rs.next())
         	 {
				branchCode = rs.getInt("b.FieldValue");
         	 }
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
		   con11.close();
		   return branchCode;
	}	
	
	public SchemeDetailsViewModel getSchemeData(int masterCode,String memoType) throws ClassNotFoundException, SQLException 
	{
		int branchCode=0;
		SchemeDetailsViewModel schemeDetailsViewModel = new SchemeDetailsViewModel();		
		
		//DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
        //Connection con = databaseConnectionService.databaseConnectionMethod();
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT IFNULL(a.Fieldvalue,'')AS schemeName,IFNULL(b.FieldValue,'') AS schemeDuration,IFNULL(c.FieldValue,'') AS minInstallmntAmt,IFNULL(d.FieldValue,'') AS allowVariableInstallmnt,IFNULL(e.FieldValue,'') AS additionalMonths,IFNULL(f.FieldValue,'') AS discountType,IFNULL(g.FieldValue,'') AS addLateDays,IFNULL(h.FieldValue,'') AS accountCode,IFNULL(i.FieldValue, '') AS multipleOf FROM SecondaryMasterDetails  a  LEFT JOIN SecondaryMasterDetails  b ON a.CompCode=  b.compcode AND a.MasterCode = b.MasterCode AND a.MasterType=b.MasterType AND b.Fieldno = 20 LEFT JOIN SecondaryMasterDetails  c ON a.CompCode=  c.compcode AND a.MasterCode = c.MasterCode AND a.MasterType=c.MasterType AND c.Fieldno = 80 LEFT JOIN SecondaryMasterDetails  d ON a.CompCode=  d.compcode AND a.MasterCode = d.MasterCode AND a.MasterType=d.MasterType AND d.Fieldno = 140 LEFT JOIN SecondaryMasterDetails  e ON a.CompCode=  e.compcode AND a.MasterCode = e.MasterCode AND a.MasterType=e.MasterType AND e.Fieldno = 30 LEFT JOIN SecondaryMasterDetails  f ON a.CompCode=  f.compcode AND a.MasterCode = f.MasterCode AND a.MasterType=f.MasterType AND f.Fieldno = 60 LEFT JOIN SecondaryMasterDetails  g ON a.CompCode=  g.compcode AND a.MasterCode = g.MasterCode AND a.MasterType=g.MasterType AND g.Fieldno = 100 LEFT JOIN SecondaryMasterDetails  h ON a.CompCode=  h.compcode AND a.MasterCode = h.MasterCode AND a.MasterType=h.MasterType AND h.Fieldno = 50 LEFT JOIN SecondaryMasterDetails i ON a.CompCode = i.compcode  AND a.MasterCode = i.MasterCode  AND a.MasterType = i.MasterType  AND i.Fieldno = 90   WHERE a.compCode=1 AND a.masterType=60 AND a.MasterCode="+masterCode+" AND a.Fieldno=10");
		   try
		   {
			while(rs.next())
         	 {
				schemeDetailsViewModel.setAccountCode(rs.getInt("accountCode"));
				schemeDetailsViewModel.setMultipleOf(rs.getInt("multipleOf"));
				schemeDetailsViewModel.setAddLateDays(rs.getString("addLateDays"));
				schemeDetailsViewModel.setDuration(rs.getInt("schemeDuration"));
				schemeDetailsViewModel.setMinAmount(rs.getInt("minInstallmntAmt"));
				if (rs.getString("allowVariableInstallmnt").equalsIgnoreCase("Yes"))
				{
					schemeDetailsViewModel.setAllowVariableInst("1");
				}
				else
				{
					schemeDetailsViewModel.setAllowVariableInst("2");
				}
				
				schemeDetailsViewModel.setAddMonths(rs.getInt("additionalMonths"));
				schemeDetailsViewModel.setDiscountType(rs.getInt("discountType"));		
				schemeDetailsViewModel.setName(rs.getString("schemeName"));
				schemeDetailsViewModel.setSchemeCode(masterCode);
				//schemeDetailsViewModel.setMultipleOf(rs.getInt("additionalMonths"));
				if (memoType == null || memoType.equals(""))
				{
					schemeDetailsViewModel.setSchemeType(1);
				}
				else if  (memoType.equalsIgnoreCase("A"))
				{
					schemeDetailsViewModel.setSchemeType(2);
				}
				else 
				{
					schemeDetailsViewModel.setSchemeType(3);
				}
				
         	 }
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
		   con11.close();
		   return schemeDetailsViewModel;
	}	
	
	public String getDdMmYyDate(int docDate)
	{		
		//Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		int date1=0;
		String date=null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   Class.forName("com.mysql.jdbc.Driver");		       
		   con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT DATE_FORMAT(DATE_ADD('1800-12-28', INTERVAL "+docDate+" DAY) ,'%d/%m/%Y') as Date");
			   
		   			while(rs.next())
		   				{
		   					date   =  rs.getString("Date");    
		   					//date = String.valueOf(date1);
		   					//System.out.println("date : "+date);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while calculating today's date "+e);
		   		//date = 0;
		   	}     
		finally
		{
			try 
			{
				con11.close();
			} 
			catch (SQLException e) 
			{			
				e.printStackTrace();
			}
		}
		//System.out.println("Date >> " +date);
		return date;
	}

	
}
