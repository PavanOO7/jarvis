package com.acme.cashmachine;

import java.sql.SQLException;
import java.util.Map;

public interface GetDataFromDbForPdf 
{	
	public String getDataFromFtpDataTable(int ownCode) throws ClassNotFoundException, SQLException;
	public int connectToClientAndUploadFileToFtp(int ownCode, String hostAddress, int postNo);
	public Map<String, Object> readDataFromCOnfigFile();
	
}
