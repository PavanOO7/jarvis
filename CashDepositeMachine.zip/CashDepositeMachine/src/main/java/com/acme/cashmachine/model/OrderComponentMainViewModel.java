/*-
 *  File    :   OrderComponentMainViewModel.java
 *  Version :   1.0
 *  Date    :   Apr 16, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

import java.time.LocalDate;
import java.util.List;

/**
 * @author
 * @date Feb 9, 2016
 * @since 1.0
 */
public class OrderComponentMainViewModel {

	public OrderComponentMainViewModel() {
	//this.savingSchemeInterest = new SavingSchemeInterest();
	}
	/**
	 * Represents type of Model 1-Order 2-Saving Scheme 3-MultiSelectionList
	 */
	private int modelType;

	/**
	 * Represents order date
	 */
	private String date;

	/**
	 * Represents supplier or customer code
	 */
	private int customerCode;

	/**
	 * Reprsents orderowncode or schemeowncode according to Model Type
	 */
	private long ownCode;

	/**
	 * Represents document No and series of Order Document
	 */
	private String voucherNo;

	/**
	 * Represents Order Location code
	 */
	private int branchCode;

	/**
	 * Represents statusCode of order [0-Pending 2-Complete 3-Partially Complete
	 * 4-Cancelled]
	 */
	private int statusCode;

	/**
	 * Represents status of order
	 */
	private String statusMessage;
	/**
	 * Represents maturity date of scheme Order
	 */
	private String maturityDate;
	/**
	 * Represents value "True" When order is Prematured or "False" when order is
	 * matured
	 */
	private Boolean isPrematured;
	/**
	 * Represents reason Message when order is prematured
	 */
	private String prematurityReasonMessage;
	/**
	 * Represents "True" Value when maturity exceeded otherwise "False"
	 */
	private Boolean isMaturityExceeded;
	/**
	 * Represents rate Instance code of that Order In case of Plain Order -->
	 * it's value retrive from OrderMain Table In Case Of Scheme Order --> it's
	 * value is rateInstance code as per Today's Date
	 */
	private int rateInstanceCode;
	/**
	 * Represents Allowed Date for next Installment creation
	 */
	private String maxInstallmentDateAllowed;

	/**
	 * Represents scheme Benefit Details when Scheme is not prematured
	 */
	private SavingSchemeInterest savingSchemeInterest;

	/**
	 * Represents all Details of Order including advance and metal details.
	 */
	private OrderDataViewModel orderDataViewModel;

	/**
	 * Represents all Details of Scheme Order.
	 */
	private SchemeDataViewModel schemeDataViewModel;

	/**
	 * Represents Customer Details
	 */
	private CustomerDetailsViewModel customerDetailsViewModel;

	/**
	 * Represents multiple instances of Order
	 */
	private List<OrderMultipleInstanceModel> multipleInstanceModel;

	/**
	 * Represents List Of Items Against Main Order
	 */
	private List<OrderItemDetailsViewModel> orderItemDetailsViewModel;

	/**
	 * Represents alert message in case of Order date is Greater than current
	 * Document date
	 */
	private String alertMessage;
	private int bankDetailsCode;
	private int nomineeCode;
	private String passbookNo;
	private int totalInstallmentPaid;
	
	private int docMasterCode;

	public int getModelType() {
		return modelType;
	}

	/**
	 *
	 * @param modelType
	 */
	public void setModelType(int modelType) {
		this.modelType = modelType;
	}

	public String getDate() {
		return date;
	}

	/**
	 *
	 * @param docDate
	 */
	public void setDate(String docDate) {
		this.date = docDate;
	}

	public int getCustomerCode() {
		return customerCode;
	}

	/**
	 *
	 * @param customerCode
	 */
	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}

	public long getOwnCode() {
		return ownCode;
	}

	/**
	 *
	 * @param ownCode
	 */
	public void setOwnCode(long ownCode) {
		this.ownCode = ownCode;
	}

	public String getVoucherNo() {
		return voucherNo;
	}

	/**
	 *
	 * @param voucherNo
	 */
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public int getStatusCode() {
		return statusCode;
	}

	/**
	 *
	 * @param statusCode
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	/**
	 *
	 * @param statusMessage
	 */
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public OrderDataViewModel getOrderDataViewModel() {
		return orderDataViewModel;
	}

	/**
	 *
	 * @param orderDataViewModel
	 */
	public void setOrderDataViewModel(OrderDataViewModel orderDataViewModel) {
		this.orderDataViewModel = orderDataViewModel;
	}

	public SchemeDataViewModel getSchemeDataViewModel() {
		return schemeDataViewModel;
	}

	public void setSchemeDataViewModel(SchemeDataViewModel schemeDataViewModel) {
		this.schemeDataViewModel = schemeDataViewModel;
	}

	public CustomerDetailsViewModel getCustomerDetailsViewModel() {
		return customerDetailsViewModel;
	}

	/**
	 *
	 * @param customerDetailsViewModel
	 */
	public void setCustomerDetailsViewModel(
			CustomerDetailsViewModel customerDetailsViewModel) {
		this.customerDetailsViewModel = customerDetailsViewModel;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public List<OrderMultipleInstanceModel> getMultipleInstanceModel() {
		return multipleInstanceModel;
	}

	public void setMultipleInstanceModel(
			List<OrderMultipleInstanceModel> multipleInstanceModel) {
		this.multipleInstanceModel = multipleInstanceModel;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	/**
	 *
	 * @param dueDate
	 */
	public void setMaturityDate(String dueDate) {
		this.maturityDate = dueDate;
	}

	public Boolean getIsPrematured() {
		return isPrematured;
	}

	public void setIsPrematured(Boolean isPrematured) {
		this.isPrematured = isPrematured;
	}

	public String getPrematurityReasonMessage() {
		return prematurityReasonMessage;
	}

	public void setPrematurityReasonMessage(String prematurityReasonMessage) {
		this.prematurityReasonMessage = prematurityReasonMessage;
	}

	public Boolean getIsMaturityExceeded() {
		return isMaturityExceeded;
	}

	public void setIsMaturityExceeded(Boolean isMaturityExceeded) {
		this.isMaturityExceeded = isMaturityExceeded;
	}

	public int getRateInstanceCode() {
		return rateInstanceCode;
	}

	public void setRateInstanceCode(int rateInstanceCode) {
		this.rateInstanceCode = rateInstanceCode;
	}

	public String getMaxInstallmentDateAllowed() {
		return maxInstallmentDateAllowed;
	}

	/**
	 *
	 * @param maxInstallmentDateAllowed
	 */
	public void setMaxInstallmentDateAllowed(String maxInstallmentDateAllowed) {
		this.maxInstallmentDateAllowed = maxInstallmentDateAllowed;
	}

	public List<OrderItemDetailsViewModel> getOrderItemDetailsViewModel() {
		return orderItemDetailsViewModel;
	}

	public void setOrderItemDetailsViewModel(
			List<OrderItemDetailsViewModel> orderItemDetailsViewModel) {
		this.orderItemDetailsViewModel = orderItemDetailsViewModel;
	}

	public SavingSchemeInterest getSavingSchemeInterest() {
		return savingSchemeInterest;
	}

	public void setSavingSchemeInterest(
			SavingSchemeInterest savingSchemeInterest) {
		this.savingSchemeInterest = savingSchemeInterest;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the bankDetailsCode
	 */
	public int getBankDetailsCode() {
		return bankDetailsCode;
	}

	/**
	 * @param bankDetailsCode
	 *            the bankDetailsCode to set
	 */
	public void setBankDetailsCode(int bankDetailsCode) {
		this.bankDetailsCode = bankDetailsCode;
	}

	/**
	 * @return the nomineeCode
	 */
	public int getNomineeCode() {
		return nomineeCode;
	}

	/**
	 * @param nomineeCode
	 *            the nomineeCode to set
	 */
	public void setNomineeCode(int nomineeCode) {
		this.nomineeCode = nomineeCode;
	}

	/**
	 * @return the passbookNo
	 */
	public String getPassbookNo() {
		return passbookNo;
	}

	/**
	 * @param passbookNo
	 *            the passbookNo to set
	 */
	public void setPassbookNo(String passbookNo) {
		this.passbookNo = passbookNo;
	}

	/**
	 * @return the totalInstallmentPaid
	 */
	public int getTotalInstallmentPaid() {
		return totalInstallmentPaid;
	}

	/**
	 * @param totalInstallmentPaid
	 *            the totalInstallmentPaid to set
	 */
	public void setTotalInstallmentPaid(int totalInstallmentPaid) {
		this.totalInstallmentPaid = totalInstallmentPaid;
	}

}
