package com.acme.cashmachine.model;

public class setPdfParam 
{
	private int documentOwnCode;
	private Boolean params;
	public int getDocumentOwnCode() {
		return documentOwnCode;
	}
	public void setDocumentOwnCode(int documentOwnCode) {
		this.documentOwnCode = documentOwnCode;
	}
	public Boolean getParams() {
		return params;
	}
	public void setParams(Boolean params) {
		this.params = params;
	}

}
