package com.acme.cashmachine.model;

public class SchemeOperationVm {
	private CustomerSchemeOutputVm data;

	public CustomerSchemeOutputVm getData() {
		return data;
	}

	public void setData(CustomerSchemeOutputVm data) {
		this.data = data;
	}

	

	
}
