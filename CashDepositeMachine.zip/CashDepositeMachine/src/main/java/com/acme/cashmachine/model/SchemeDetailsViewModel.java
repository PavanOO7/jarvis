package com.acme.cashmachine.model;

import java.math.BigDecimal;

/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class SchemeDetailsViewModel {

	/**
	 * Represents scheme name
	 */
	private String name;

	/**
	 * Represents scheme duration
	 */
	private int duration;

	/**
	 * Represents additional months
	 */
	private int addMonths;

	/**
	 * Represents type of scheme [ 1.Plain (Cash) 2.Metal Booking 3.Rate Booking
	 * (avg rate) ]
	 */
	private int schemeType;

	/**
	 * Represents permission to allow [1.Yes 2.No ]
	 */
	private String allowVariableInst;

	/**
	 * Represents discount type [ 1.Additional Installment 2.Daily Interest
	 * 3.Percentage ]
	 */
	private int discountType;

	/**
	 * Represents discount value according to type of discount
	 */
	private double discountValue;

	/**
	 * Represents item type code [1.Gold 2.Silver]
	 */
	private int itemTypeCode;

	/**
	 * Represents scheme item code
	 */
	private int itemCode;

	/**
	 * Represents purity of order
	 */
	private BigDecimal purity;

	/**
	 * Represents minimum installment amount
	 */
	private int minAmount;

	/**
	 * Represents installment in multiple of
	 */
	private int multipleOf;

	/**
	 * Represents late days to maturity [1.Yes 2.No]
	 */
	private String addLateDays;

	/**
	 * Represents flag for Installment Late If Not Recived Before [ 1.Day Of
	 * Joining 2.Fix Day Of The Month ]
	 */
	private int ifNotBefore;

	/**
	 * Represents Day Of Month
	 */
	private int dayOfMonth;

	/**
	 * Represents if Late Extend Maturity By [1.Adding Late Days 2.Adding Late
	 * Days Devided By Duration 3.Adding Month]
	 */
	private int extendBy;

	/**
	 * Represents grace days allowed
	 */
	private int graceDays;

	/**
	 * Account To Which Effect of Scheme Advance Will Go UCB 29 feb 16
	 */
	private int accountCode;

	/**
	 * Account To Which Scheme Discount Effect Will Go UCB 29 feb 16
	 *
	 * @return
	 */
	private int discountAccountCode;
	/**
	 * scheme master owncode
	 */
	private long schemeCode;

	private BigDecimal benefitPoints;

	/* related Kyc and Bank Details Mahesh 25.01.2018 */
	private BigDecimal restrictInterestBenefitFactor;
	private boolean kycRequired;
	private boolean bankAccountDetailsRequired;
	private int noOfIntallementsAllowedWithoutKyc;

	public int getAccountCode() {
		return accountCode;
	}

	public void setAccountCode(int accountCode) {
		this.accountCode = accountCode;
	}

	public int getDiscountAccountCode() {
		return discountAccountCode;
	}

	public void setDiscountAccountCode(int discountAccountCode) {
		this.discountAccountCode = discountAccountCode;
	}

	public String getName() {
		return name;
	}

	/**
	 *
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	/**
	 *
	 * @param duration
	 */
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getAddMonths() {
		return addMonths;
	}

	/**
	 *
	 * @param addMonths
	 */
	public void setAddMonths(int addMonths) {
		this.addMonths = addMonths;
	}

	public int getSchemeType() {
		return schemeType;
	}

	/**
	 *
	 * @param schemeType
	 */
	public void setSchemeType(int schemeType) {
		this.schemeType = schemeType;
	}

	public String getAllowVariableInst() {
		return allowVariableInst;
	}

	/**
	 *
	 * @param allowVariableInst
	 */
	public void setAllowVariableInst(String allowVariableInst) {
		this.allowVariableInst = allowVariableInst;
	}

	public int getDiscountType() {
		return discountType;
	}

	/**
	 *
	 * @param discountType
	 */
	public void setDiscountType(int discountType) {
		this.discountType = discountType;
	}

	public double getDiscountValue() {
		return discountValue;
	}

	/**
	 *
	 * @param discountValue
	 */
	public void setDiscountValue(double discountValue) {
		this.discountValue = discountValue;
	}

	public int getItemTypeCode() {
		return itemTypeCode;
	}

	/**
	 *
	 * @param itemTypeCode
	 */
	public void setItemTypeCode(int itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	public int getItemCode() {
		return itemCode;
	}

	/**
	 *
	 * @param itemCode
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public BigDecimal getPurity() {
		return purity;
	}

	/**
	 *
	 * @param purity
	 */
	public void setPurity(BigDecimal purity) {
		this.purity = purity;
	}

	public int getMinAmount() {
		return minAmount;
	}

	/**
	 *
	 * @param minAmount
	 */
	public void setMinAmount(int minAmount) {
		this.minAmount = minAmount;
	}

	public int getMultipleOf() {
		return multipleOf;
	}

	/**
	 *
	 * @param multipleOf
	 */
	public void setMultipleOf(int multipleOf) {
		this.multipleOf = multipleOf;
	}

	public String getAddLateDays() {
		return addLateDays;
	}

	/**
	 *
	 * @param addLateDays
	 */
	public void setAddLateDays(String addLateDays) {
		this.addLateDays = addLateDays;
	}

	public int getIfNotBefore() {
		return ifNotBefore;
	}

	/**
	 *
	 * @param ifNotBefore
	 */
	public void setIfNotBefore(int ifNotBefore) {
		this.ifNotBefore = ifNotBefore;
	}

	public int getDayOfMonth() {
		return dayOfMonth;
	}

	/**
	 *
	 * @param dayOfMonth
	 */
	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}

	public int getExtendBy() {
		return extendBy;
	}

	/**
	 *
	 * @param extendBy
	 */
	public void setExtendBy(int extendBy) {
		this.extendBy = extendBy;
	}

	public int getGraceDays() {
		return graceDays;
	}

	/**
	 *
	 * @param graceDays
	 */
	public void setGraceDays(int graceDays) {
		this.graceDays = graceDays;
	}

	public long getSchemeCode() {
		return schemeCode;
	}

	/**
	 *
	 * @param schemeCode
	 */
	public void setSchemeCode(long schemeCode) {
		this.schemeCode = schemeCode;
	}

	/**
	 * @return the benefitPoints
	 */
	public BigDecimal getBenefitPoints() {
		return benefitPoints;
	}

	/**
	 * @param benefitPoints
	 *            the benefitPoints to set
	 */
	public void setBenefitPoints(BigDecimal benefitPoints) {
		this.benefitPoints = benefitPoints;
	}

	/**
	 * @return the restrictInterestBenefitFactor
	 */
	public BigDecimal getRestrictInterestBenefitFactor() {
		return restrictInterestBenefitFactor;
	}

	/**
	 * @param restrictInterestBenefitFactor
	 *            the restrictInterestBenefitFactor to set
	 */
	public void setRestrictInterestBenefitFactor(
			BigDecimal restrictInterestBenefitFactor) {
		this.restrictInterestBenefitFactor = restrictInterestBenefitFactor;
	}

	/**
	 * @return the kycRequired
	 */
	public boolean isKycRequired() {
		return kycRequired;
	}

	/**
	 * @param kycRequired
	 *            the kycRequired to set
	 */
	public void setKycRequired(boolean kycRequired) {
		this.kycRequired = kycRequired;
	}

	/**
	 * @return the bankAccountDetailsRequired
	 */
	public boolean isBankAccountDetailsRequired() {
		return bankAccountDetailsRequired;
	}

	/**
	 * @param bankAccountDetailsRequired
	 *            the bankAccountDetailsRequired to set
	 */
	public void setBankAccountDetailsRequired(boolean bankAccountDetailsRequired) {
		this.bankAccountDetailsRequired = bankAccountDetailsRequired;
	}

	/**
	 * @return the noOfIntallementsAllowedWithoutKyc
	 */
	public int getNoOfIntallementsAllowedWithoutKyc() {
		return noOfIntallementsAllowedWithoutKyc;
	}

	/**
	 * @param noOfIntallementsAllowedWithoutKyc
	 *            the noOfIntallementsAllowedWithoutKyc to set
	 */
	public void setNoOfIntallementsAllowedWithoutKyc(
			int noOfIntallementsAllowedWithoutKyc) {
		this.noOfIntallementsAllowedWithoutKyc = noOfIntallementsAllowedWithoutKyc;
	}

}
