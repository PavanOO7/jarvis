package com.acme.cashmachine.model;

import java.util.Map;

public class SchemeValidatorVm {
private int errorCode;
private String errorMsg;
private Map<String,Object> result;
public int getErrorCode() {
	return errorCode;
}
public void setErrorCode(int errorCode) {
	this.errorCode = errorCode;
}
public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public Map<String, Object> getResult() {
	return result;
}
public void setResult(Map<String, Object> result) {
	this.result = result;
}

}
