package com.acme.cashmachine.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.stereotype.Service;

@Service
public class DatabaseConnectionService 
{		
	//ReadDataFromWebConfig readDataFromWebConfig = new ReadDataFromWebConfig(); 
	  
	public  Connection databaseConnectionMethod()	
	{			
		Connection con = null;
		BufferedReader br =null;
		try
		{
			  ClassLoader classLoader = getClass().getClassLoader();
			  File file = new File(classLoader.getResource("\\Web-config.txt").getFile());
			  Class.forName("com.mysql.jdbc.Driver");
	    	  String textData = null;
			 // File file = new File("C:\\AcmeTmpFiles\\Web-config.txt");		 
			  br = new BufferedReader(new FileReader(file));		 			 
			  while ((textData = br.readLine()) != null)
		      //con = DriverManager.getConnection(textData,"AcmeInfi","ProteasLankans");
			  con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			  
			  //System.out.println("Con >> "+con);
			  return con;
		}
		catch(Exception e)
	   	{
			
	   		System.out.println("Error while making Database connection "+e);
	   		return null;
	   	}	
	}
}
