/*-
 *  File    :   OrderDataViewModel.java
 *  Version	:   1.0
 *	Date    :   Feb 18, 2016
 *  Author  :   Monika
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class OrderDataViewModel {

	/**
	 * Represents type of order [1-Purchase Order 2-Sales Order 3-Repair Order]
	 */
	private int orderType;
	/**
	 * Represents RateFreezed status [ True/False ]
	 */
	private boolean isRateFreezed;
	/**
	 * Represents Instance code of Rate
	 */
	private int rateInstanceCode;
	/**
	 * Represents type of Item [1-Gold 2-Silver ]
	 */
	private int itemType;
	/**
	 * Represents total metal against order
	 */
	private BigDecimal totalMetal;
	/**
	 * Represents total advance against order
	 */
	private BigDecimal totalAdvance;

	private BigDecimal totalTaxOnAdvance;

	private BigDecimal rateFreezePercentage;
	private BigDecimal rateFreezeAdvance;

	private String tag;
	public BigDecimal getTotalTaxOnAdvance() {
		return totalTaxOnAdvance;
	}

	public void setTotalTaxOnAdvance(BigDecimal totalTaxOnAdvance) {
		this.totalTaxOnAdvance = totalTaxOnAdvance;
	}

	/**
	 * Represents pending advance and metal transaction ledger
	 */
	private List<OrderAdvanceAndMetalDetailsModel> orderAdvanceMetalDetails = new ArrayList<OrderAdvanceAndMetalDetailsModel>();

	/**
	 * Represents order Item Details
	 */
	private List<OrderItemDetailsViewModel> orderItemDetails = new ArrayList<OrderItemDetailsViewModel>();

	public int getOrderType() {
		return orderType;
	}

	/**
	 *
	 * @param orderType
	 */
	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	public boolean isRateFreezed() {
		return isRateFreezed;
	}

	/**
	 *
	 * @param isRateFreezed
	 */
	public void setRateFreezed(boolean isRateFreezed) {
		this.isRateFreezed = isRateFreezed;
	}

	public int getRateInstanceCode() {
		return rateInstanceCode;
	}

	/**
	 *
	 * @param rateInstanceCode
	 */
	public void setRateInstanceCode(int rateInstanceCode) {
		this.rateInstanceCode = rateInstanceCode;
	}

	public int getItemType() {
		return itemType;
	}

	/**
	 *
	 * @param itemType
	 */
	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getTotalMetal() {
		return totalMetal;
	}

	/**
	 *
	 * @param totalMetal
	 */
	public void setTotalMetal(BigDecimal totalMetal) {
		this.totalMetal = totalMetal;
	}

	public BigDecimal getTotalAdvance() {
		return totalAdvance;
	}

	/**
	 *
	 * @param totalAdvance
	 */
	public void setTotalAdvance(BigDecimal totalAdvance) {
		this.totalAdvance = totalAdvance;
	}

	public List<OrderAdvanceAndMetalDetailsModel> getOrderAdvanceMetalDetails() {
		return orderAdvanceMetalDetails;
	}

	/**
	 *
	 * @param orderAdvanceMetalDetails
	 */
	public void setOrderAdvanceMetalDetails(
			List<OrderAdvanceAndMetalDetailsModel> orderAdvanceMetalDetails) {
		this.orderAdvanceMetalDetails = orderAdvanceMetalDetails;
	}

	public List<OrderItemDetailsViewModel> getOrderItemDetails() {
		return orderItemDetails;
	}

	/**
	 *
	 * @param orderItemDetails
	 */
	public void setOrderItemDetails(
			List<OrderItemDetailsViewModel> orderItemDetails) {
		this.orderItemDetails = orderItemDetails;
	}

	public BigDecimal getRateFreezePercentage() {
		return rateFreezePercentage;
	}

	public void setRateFreezePercentage(BigDecimal rateFreezePercentage) {
		this.rateFreezePercentage = rateFreezePercentage;
	}

	public BigDecimal getRateFreezeAdvance() {
		return rateFreezeAdvance;
	}

	public void setRateFreezeAdvance(BigDecimal rateFreezeAdvance) {
		this.rateFreezeAdvance = rateFreezeAdvance;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

}
