/** Automatically generated file. DO NOT MODIFY */
package com.prashant.adesara.socket.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}