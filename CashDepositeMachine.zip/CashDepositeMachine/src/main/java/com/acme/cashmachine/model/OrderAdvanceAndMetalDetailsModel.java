/*-
 *  File    :   OrderAdvanceAndMetalDetailsModel.java
 *  Version :   1.0
 *  Date    :   Jul 20, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author
 * @date Feb 9, 2016
 * @since 1.0
 */
public class OrderAdvanceAndMetalDetailsModel {

	/**
	 * Represents date of Order advance Document
	 */
	private LocalDate date;
	/**
	 * Represents owncode of Order advance Document
	 */
	private long voucherOwnCode;
	/**
	 * Represents DocumentNo and Series of Order advance Document
	 */
	private String voucherNo;
	/**
	 * Represents metal [ + For Jama - For Return ]
	 */
	private BigDecimal metal;
	/**
	 * Represents advance [ + For Jama - For Return ]
	 */
	private BigDecimal advance;
	/**
	 * Represents purity of order
	 */
	private BigDecimal purity;

	private BigDecimal balance;

	private BigDecimal fineWt;

	private BigDecimal estimatedFine;

	private BigDecimal rate;
	private BigDecimal taxOnAdvance;
	private BigDecimal inclusiveAdvance;

	public BigDecimal getTaxOnAdvance() {
		return taxOnAdvance;
	}

	public void setTaxOnAdvance(BigDecimal taxOnAdvance) {
		this.taxOnAdvance = taxOnAdvance;
	}

	/**
	 * Represents document Own Code
	 */
	private long documentOwnCode;

	public long getVoucherOwnCode() {
		return voucherOwnCode;
	}

	/**
	 *
	 * @param voucherOwnCode
	 */
	public void setVoucherOwnCode(long voucherOwnCode) {
		this.voucherOwnCode = voucherOwnCode;
	}

	public BigDecimal getMetal() {
		return metal;
	}

	/**
	 *
	 * @param metal
	 */
	public void setMetal(BigDecimal metal) {
		this.metal = metal;
	}

	public BigDecimal getPurity() {
		return purity;
	}

	/**
	 *
	 * @param purity
	 */
	public void setPurity(BigDecimal purity) {
		this.purity = purity;
	}

	public String getVoucherNo() {
		return voucherNo;
	}

	/**
	 *
	 * @param voucherNo
	 */
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public LocalDate getDate() {
		return date;
	}

	/**
	 *
	 * @param date
	 */
	public void setDate(LocalDate date) {
		this.date = date;
	}

	/**
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * @return the advance
	 */
	public BigDecimal getAdvance() {
		return advance;
	}

	/**
	 * @param advance
	 *            the advance to set
	 */
	public void setAdvance(BigDecimal advance) {
		this.advance = advance;
	}

	/**
	 * @return the fineWt
	 */
	public BigDecimal getFineWt() {
		return fineWt;
	}

	/**
	 * @param fineWt
	 *            the fineWt to set
	 */
	public void setFineWt(BigDecimal fineWt) {
		this.fineWt = fineWt;
	}

	/**
	 * @return the estimatedFine
	 */
	public BigDecimal getEstimatedFine() {
		return estimatedFine;
	}

	/**
	 * @param estimatedFine
	 *            the estimatedFine to set
	 */
	public void setEstimatedFine(BigDecimal estimatedFine) {
		this.estimatedFine = estimatedFine;
	}

	public long getDocumentOwnCode() {
		return documentOwnCode;
	}

	public void setDocumentOwnCode(long documentOwnCode) {
		this.documentOwnCode = documentOwnCode;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public BigDecimal getInclusiveAdvance() {
		return inclusiveAdvance;
	}

	public void setInclusiveAdvance(BigDecimal inclusiveAdvance) {
		this.inclusiveAdvance = inclusiveAdvance;
	}

}
