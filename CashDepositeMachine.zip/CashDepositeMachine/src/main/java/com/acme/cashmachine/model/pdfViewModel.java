package com.acme.cashmachine.model;

public class pdfViewModel 
{
	private int documentOwnCode;
	private boolean isNative;
	public int getDocumentOwnCode() {
		return documentOwnCode;
	}
	public void setDocumentOwnCode(int documentOwnCode) {
		this.documentOwnCode = documentOwnCode;
	}
	public boolean isNative() {
		return isNative;
	}
	public void setNative(boolean isNative) {
		this.isNative = isNative;
	}
	
	
}
