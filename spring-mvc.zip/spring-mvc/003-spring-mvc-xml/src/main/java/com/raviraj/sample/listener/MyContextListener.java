/*-
 *  File    :   MyContextListener.java
 *  Version	:   1.0
 *	Date    :   Sep 2, 2017
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.raviraj.sample.listener;


import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


/**
 * @author Raviraj S Mahamuni
 * @date Sep 2, 2017
 * @since 1.0
 */
// @WebListener
public class MyContextListener implements ServletContextListener {

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
     * ServletContextEvent)
     */
    @Override
    public void contextDestroyed(ServletContextEvent arg0) {

        System.out.println("MyContextListener::contextDestroyed() called");

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * javax.servlet.ServletContextListener#contextInitialized(javax.servlet
     * .ServletContextEvent)
     */
    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        System.out.println("MyContextListener::contextInitialized() called");

    }

}
