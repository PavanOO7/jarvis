package com.acme.cashmachine.model;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataInsertService
{
	DatabaseConnectionService databaseConnectionService =new DatabaseConnectionService();
	Connection con = databaseConnectionService.databaseConnectionMethod();

	public void insertRecordIntoAutoNoTable(String defaultSeries,int documentMasterCode) throws Exception
	{
		int documentNo=1;
		String seriesFromAutoNoTable=defaultSeries;
		 Connection con11=null;
		System.out.println("documentNo > "+documentNo+" seriesFromAutoNoTable > "+defaultSeries);
		try
		{
		   //getRecordFromDocMasterTable();
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		      
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();
		   int rs = 0;    	    
		   rs=stmt1.executeUpdate("INSERT INTO AutoNoTableForDocument  VALUES('1',"+documentMasterCode+",'"+defaultSeries+"','1','0','0','0')");	   
		   if (rs == 0)	
		   {
			   throw new Exception("Error while inserting Record into AutoNoTableForDocument");
		   }   
		 
		}
		catch(Exception e)
		{			
			throw new Exception("Error while inserting Record into AutoNoTableForDocument : "+e.getMessage());
		}   
		
		finally
		{
			con11.close();			
		}
	}

    public void insertRecordIntoAutoNoTable(int documentMasterCode,String defaultSeries) throws Exception
	{		
		//seriesFromAutoNoTable=defaultSeries;
		//System.out.println("documentNo > "+documentNo+" seriesFromAutoNoTable > "+seriesFromAutoNoTable);
    	Connection con11=null;
		try
		{
		   //getRecordFromDocMasterTable();
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
	
		   java.sql.Statement stmt1=con11.createStatement();
		   int rs = 0;    	    
		   rs=stmt1.executeUpdate("INSERT INTO AutoNoTableForDocument  VALUES('1',"+documentMasterCode+",'"+defaultSeries+"','0','0','0','0')");	   
		   if (rs == 0)	
		   {
			   throw new Exception("Error while inserting Record into AutoNoTableForDocument");
		   }   
		 
		}
		catch(Exception e)
		{			
			throw new Exception("Error while inserting Record into AutoNoTableForDocument : "+e.getMessage());
		}   
		
		finally
		{
			con11.close();			
		}
	}
}
