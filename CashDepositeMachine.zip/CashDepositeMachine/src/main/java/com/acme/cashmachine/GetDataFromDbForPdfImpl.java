package com.acme.cashmachine;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.acme.cashmachine.model.SchemeOrderDetailsModel;

@Service
public class GetDataFromDbForPdfImpl implements GetDataFromDbForPdf
{
	 private static Socket socket;
	 
	@Override
	public String getDataFromFtpDataTable(int ownCode) throws ClassNotFoundException, SQLException
	{		  
	       Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       String PdfName = null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT pdfName FROM FtpDataTable WHERE OwnCode = "+ownCode+"");
		   try
		   {
			while(rs.next())
         	 {			
				//schemeOrderDetailsModel.setAdvance(rs.getBigDecimal("advanceAmount"));
				PdfName = rs.getString("PdfName");
				PdfName = PdfName.trim();
				//System.out.println("PdfName ::: "+PdfName);
         	 }			
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
		   con11.close();
		   //PdfName = "20180518_JBH-148_.Pdf";
		   return PdfName;
	}
	
	@Override
    public int connectToClientAndUploadFileToFtp(int ownCode,String hostAddress,int portNo)
    {
		int flag = 0;
    	try
        {
            // String host = "172.16.2.36";
    		//System.out.println("hostAddress :: "+hostAddress+" portNo ::  "+portNo);
            String host = hostAddress;
            int port = portNo;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket(address, port);
 
            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
 
            // String number = "38860";
            String number = " 1       "+ownCode+"    12Microsoft XPS Document Writer";
 
            String sendMessage = number + "\n";
            bw.write(sendMessage);
            bw.flush();
           // System.out.println("Message sent to the server : "+sendMessage);
 
            //Get the return message from the server
            InputStream is = socket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String message = br.readLine();
           // System.out.println("Message received from the server : " +message);
            if (!message.equals(""))
            {
            	flag = 1;
            	//System.out.println("1.00 flag >> "+flag);
            	
            	return flag;
            }
            else
            {
            	flag = 0;
            	//System.out.println("2.000 flag >> "+flag);
            	return flag;
            }

        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
        finally
        {
            //Closing the socket
            try
            {
                socket.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    	//System.out.println("3.000 flag >> "+flag);
		return flag;
    }
	
	
	Properties configFile;
	@Override
    public Map<String,Object> readDataFromCOnfigFile()
    {
		Map<String, Object> readDatFromConfigFile = new LinkedHashMap<String, Object>();
		configFile = new java.util.Properties();
 		try 
 		{
 			configFile.load(this.getClass().getClassLoader().
 		    getResourceAsStream("Server_Data.config"));
 			String hostAddress = this.configFile.getProperty("HOST_ADDRESS");
 			String portNo      = this.configFile.getProperty("PORT_NO");
 			String ftpAddress  = this.configFile.getProperty("FTP_ADDRESS");
 			String userName    = this.configFile.getProperty("USER_NAME");
 			String password    = this.configFile.getProperty("PASSWORD");
 			//System.out.println("userName >> "+userName);
 			//System.out.println("password >> "+password);
 			readDatFromConfigFile.put("hostAddress", hostAddress);
 			readDatFromConfigFile.put("ftpAddress", ftpAddress);
 			readDatFromConfigFile.put("userName", userName);
 			readDatFromConfigFile.put("password", password);
 			readDatFromConfigFile.put("portNo", portNo);
 		}
 		catch(Exception eta)
 		{
 			eta.printStackTrace();
 		}
		return readDatFromConfigFile;
     }

}
