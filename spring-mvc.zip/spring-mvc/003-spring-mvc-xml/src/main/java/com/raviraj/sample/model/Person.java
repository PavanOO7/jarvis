/*-
 *  File    :   Person.java
 *  Version	:   1.0
 *	Date    :   Nov 13, 2017
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.raviraj.sample.model;


import java.util.Date;


/**
 * @author Raviraj S Mahamuni
 * @date Nov 13, 2017
 * @since 1.0
 */
public class Person {

    private PersonId personId;

    private int no;
    private String name;
    private Date date;

    /**
     *
     */
    public Person() {
        this.no = 1;
        this.name = "sdfdsf";
        this.date = new Date();
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public PersonId getPersonId() {
        return personId;
    }

    public void setPersonId(PersonId personId) {
        this.personId = personId;
    }

    @Override
    public String toString() {
        return "Person [personId=" + personId + ", no=" + no + ", name=" + name
                + ", date=" + date + "]";
    }

}
