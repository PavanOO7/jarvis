/*-
 *  File    :   OrderMultipleInstanceModel.java
 *  Version :   1.0
 *  Date    :   Apr 16, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.cashmachine.model;

import java.time.LocalDate;


/**
 * @author
 * @date Feb 14, 2016
 * @since 1.0
 */
public class OrderMultipleInstanceModel {

    /**
     * Represents model type [1-Order 2-Scheme]
     */
    private int modelType;

    /**
     * Represents Date of Order
     */
    private LocalDate date;

    /**
     * Represents Customer name
     */
    private String customerName;

    /**
     * Represents owncode of order
     */
    private long orderOwnCode;

    /**
     * Represents owncode of scheme order
     */
    private long schemeOwnCode;

    public long getOrderOwnCode() {
        return orderOwnCode;
    }

    /**
     *
     * @param orderOwnCode
     */
    public void setOrderOwnCode(long orderOwnCode) {
        this.orderOwnCode = orderOwnCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    /**
     *
     * @param customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getModelType() {
        return modelType;
    }

    /**
     *
     * @param modelType
     */
    public void setModelType(int modelType) {
        this.modelType = modelType;
    }

    public LocalDate getDate() {
        return date;
    }

    /**
     *
     * @param date
     */
    public void setDate(LocalDate date) {
        this.date = date;
    }

    public long getSchemeOwnCode() {
        return schemeOwnCode;
    }

    /**
     *
     * @param schemeOwnCode
     */
    public void setSchemeOwnCode(long schemeOwnCode) {
        this.schemeOwnCode = schemeOwnCode;
    }

}
