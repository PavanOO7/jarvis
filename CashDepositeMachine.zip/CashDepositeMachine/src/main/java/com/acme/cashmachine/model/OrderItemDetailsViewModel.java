/*-
 *  File    :   OrderItemDetailsViewModel.java
 *  Version :   1.0
 *  Date    :   Mar 28, 2016
 *  Author  :   Monika
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.cashmachine.model;


import java.math.BigDecimal;



/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class OrderItemDetailsViewModel {

    /**
     * Represents owncode of {@link OrderItem}
     */
    private Long ownCode;
    /**
     * Represents 0-UnProcessed 1-Given To Subcontractor 2-Ready 3-Delivered
     */
    private Boolean currentStatus;
    /**
     * Represents balQty of order Item
     */
    private double balQty;
    /**
     * Represents rate against Order Item
     */
    private BigDecimal rate;
    /**
     * Represents labourRate of Order Item
     */
    private double labourRate;
    /**
     * Represents Labour Calculation Method
     */
    private int labourCalOn;
    /**
     * Represents labour Type Code
     */
    private int labourType;
    /**
     * Represents wastage Rate
     */
    private double wastageRate;
    /**
     * Represents wastage Calculation method
     */
    private int wastageCalOn;
    /**
     * Represents other Charges
     */
    private double otherCharges;

    private int referenceEmployeeCode;
    private String referenceEmployeeName;

    public Long getOwnCode() {
        return ownCode;
    }

    public void setOwnCode(Long ownCode) {
        this.ownCode = ownCode;
    }

    public Boolean getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(Boolean currentStatus) {
        this.currentStatus = currentStatus;
    }

    public double getBalQty() {
        return balQty;
    }

    public void setBalQty(double balQty) {
        this.balQty = balQty;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public double getLabourRate() {
        return labourRate;
    }

    public void setLabourRate(double labourRate) {
        this.labourRate = labourRate;
    }

    public int getLabourCalOn() {
        return labourCalOn;
    }

    public void setLabourCalOn(int labourCalOn) {
        this.labourCalOn = labourCalOn;
    }

    public int getLabourType() {
        return labourType;
    }

    public void setLabourType(int labourType) {
        this.labourType = labourType;
    }

    public double getWastageRate() {
        return wastageRate;
    }

    public void setWastageRate(double wastageRate) {
        this.wastageRate = wastageRate;
    }

    public int getWastageCalOn() {
        return wastageCalOn;
    }

    public void setWastageCalOn(int wastageCalOn) {
        this.wastageCalOn = wastageCalOn;
    }

    public double getOtherCharges() {
        return otherCharges;
    }

    public void setOtherCharges(double otherCharges) {
        this.otherCharges = otherCharges;
    }

    public int getReferenceEmployeeCode() {
        return referenceEmployeeCode;
    }

    public void setReferenceEmployeeCode(int referenceEmployeeCode) {
        this.referenceEmployeeCode = referenceEmployeeCode;
    }

    public String getReferenceEmployeeName() {
        return referenceEmployeeName;
    }

    public void setReferenceEmployeeName(String referenceEmployeeName) {
        this.referenceEmployeeName = referenceEmployeeName;
    }

}
