/*-
 *  File    :   MyRequestListener.java
 *  Version	:   1.0
 *	Date    :   Sep 2, 2017
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.sample.listener;


import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpServletRequest;


/**
 * @author Raviraj S Mahamuni
 * @date Sep 2, 2017
 * @since 1.0
 */
// @WebListener
public class MyRequestListener implements ServletRequestListener {

    private AtomicInteger count = new AtomicInteger(1);

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.ServletRequestListener#requestDestroyed(javax.servlet.
     * ServletRequestEvent)
     */
    @Override
    public void requestDestroyed(ServletRequestEvent arg0) {

        HttpServletRequest req = (HttpServletRequest) arg0.getServletRequest();
        System.out.println("MyRequestListener:: requestDestroyed() called for "
                + req.getRequestURL().toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * javax.servlet.ServletRequestListener#requestInitialized(javax.servlet
     * .ServletRequestEvent)
     */
    @Override
    public void requestInitialized(ServletRequestEvent arg0) {
        HttpServletRequest req = (HttpServletRequest) arg0.getServletRequest();
        System.out.println("MyRequestListener:: requestInitialized() called "
                + req.getRequestURL().toString() + ". Req  Count is "
                + count.getAndIncrement());

    }
}
