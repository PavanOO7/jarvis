/**
 *
 */
package com.acme.cashmachine.model;

import java.math.BigDecimal;

/**
 * @author Mahesh S. Nikam
 * @date Jan 28, 2018
 */
public class PaymentDetailsVm {

	private BigDecimal amount;
	private BigDecimal cardChargesAmount;
	private BigDecimal cardChargesPercentage;
	private String creditAccountName;
	private int creditAccountCode;
	private int referencePersonCode;
	private String referencePersonName;
	private String narration;
	private BigDecimal originalAmt;
	private int paymentType;
	private String paymentTypeName;

	private String authorizationNo;

	private String cardNo;
	private String creditCardName;
	private int creditCardCode;
	private int creditCardNoOfDigits;
	private String creditCardSubTypeName;
	private int creditCardSubTypeCode;

	/**
	 *
	 */
	public PaymentDetailsVm() {

	}

	/**
	 * @return the creditCardCode
	 */
	public int getCreditCardCode() {
		return creditCardCode;
	}

	/**
	 * @param creditCardCode
	 *            the creditCardCode to set
	 */
	public void setCreditCardCode(int creditCardCode) {
		this.creditCardCode = creditCardCode;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the cardChargesAmount
	 */
	public BigDecimal getCardChargesAmount() {
		return cardChargesAmount;
	}

	/**
	 * @param cardChargesAmount
	 *            the cardChargesAmount to set
	 */
	public void setCardChargesAmount(BigDecimal cardChargesAmount) {
		this.cardChargesAmount = cardChargesAmount;
	}

	/**
	 * @return the cardChargesPercentage
	 */
	public BigDecimal getCardChargesPercentage() {
		return cardChargesPercentage;
	}

	/**
	 * @param cardChargesPercentage
	 *            the cardChargesPercentage to set
	 */
	public void setCardChargesPercentage(BigDecimal cardChargesPercentage) {
		this.cardChargesPercentage = cardChargesPercentage;
	}

	/**
	 * @return the creditAccountName
	 */
	public String getCreditAccountName() {
		return creditAccountName;
	}

	/**
	 * @param creditAccountName
	 *            the creditAccountName to set
	 */
	public void setCreditAccountName(String creditAccountName) {
		this.creditAccountName = creditAccountName;
	}

	/**
	 * @return the creditAccountCode
	 */
	public int getCreditAccountCode() {
		return creditAccountCode;
	}

	/**
	 * @param creditAccountCode
	 *            the creditAccountCode to set
	 */
	public void setCreditAccountCode(int creditAccountCode) {
		this.creditAccountCode = creditAccountCode;
	}

	/**
	 * @return the referencePersonCode
	 */
	public int getReferencePersonCode() {
		return referencePersonCode;
	}

	/**
	 * @param referencePersonCode
	 *            the referencePersonCode to set
	 */
	public void setReferencePersonCode(int referencePersonCode) {
		this.referencePersonCode = referencePersonCode;
	}

	/**
	 * @return the referencePersonName
	 */
	public String getReferencePersonName() {
		return referencePersonName;
	}

	/**
	 * @param referencePersonName
	 *            the referencePersonName to set
	 */
	public void setReferencePersonName(String referencePersonName) {
		this.referencePersonName = referencePersonName;
	}

	/**
	 * @return the narration
	 */
	public String getNarration() {
		return narration;
	}

	/**
	 * @param narration
	 *            the narration to set
	 */
	public void setNarration(String narration) {
		this.narration = narration;
	}

	/**
	 * @return the originalAmt
	 */
	public BigDecimal getOriginalAmt() {
		return originalAmt;
	}

	/**
	 * @param originalAmt
	 *            the originalAmt to set
	 */
	public void setOriginalAmt(BigDecimal originalAmt) {
		this.originalAmt = originalAmt;
	}

	/**
	 * @return the paymentType
	 */
	public int getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType
	 *            the paymentType to set
	 */
	public void setPaymentType(int paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the paymentTypeName
	 */
	public String getPaymentTypeName() {
		return paymentTypeName;
	}

	/**
	 * @param paymentTypeName
	 *            the paymentTypeName to set
	 */
	public void setPaymentTypeName(String paymentTypeName) {
		this.paymentTypeName = paymentTypeName;
	}

	/**
	 * @return the authorizationNo
	 */
	public String getAuthorizationNo() {
		return authorizationNo;
	}

	/**
	 * @param authorizationNo
	 *            the authorizationNo to set
	 */
	public void setAuthorizationNo(String authorizationNo) {
		this.authorizationNo = authorizationNo;
	}

	/**
	 * @return the cardNo
	 */
	public String getCardNo() {
		return cardNo;
	}

	/**
	 * @param cardNo
	 *            the cardNo to set
	 */
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	/**
	 * @return the creditCardName
	 */
	public String getCreditCardName() {
		return creditCardName;
	}

	/**
	 * @param creditCardName
	 *            the creditCardName to set
	 */
	public void setCreditCardName(String creditCardName) {
		this.creditCardName = creditCardName;
	}

	/**
	 * @return the creditCardNoOfDigits
	 */
	public int getCreditCardNoOfDigits() {
		return creditCardNoOfDigits;
	}

	/**
	 * @param creditCardNoOfDigits
	 *            the creditCardNoOfDigits to set
	 */
	public void setCreditCardNoOfDigits(int creditCardNoOfDigits) {
		this.creditCardNoOfDigits = creditCardNoOfDigits;
	}

	/**
	 * @return the creditCardSubTypeName
	 */
	public String getCreditCardSubTypeName() {
		return creditCardSubTypeName;
	}

	/**
	 * @param creditCardSubTypeName
	 *            the creditCardSubTypeName to set
	 */
	public void setCreditCardSubTypeName(String creditCardSubTypeName) {
		this.creditCardSubTypeName = creditCardSubTypeName;
	}

	/**
	 * @return the creditCardSubTypeCode
	 */
	public int getCreditCardSubTypeCode() {
		return creditCardSubTypeCode;
	}

	/**
	 * @param creditCardSubTypeCode
	 *            the creditCardSubTypeCode to set
	 */
	public void setCreditCardSubTypeCode(int creditCardSubTypeCode) {
		this.creditCardSubTypeCode = creditCardSubTypeCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime * result
				+ ((authorizationNo == null) ? 0 : authorizationNo.hashCode());
		result = prime
				* result
				+ ((cardChargesAmount == null) ? 0 : cardChargesAmount
						.hashCode());
		result = prime
				* result
				+ ((cardChargesPercentage == null) ? 0 : cardChargesPercentage
						.hashCode());
		result = prime * result + ((cardNo == null) ? 0 : cardNo.hashCode());
		result = prime * result + creditAccountCode;
		result = prime
				* result
				+ ((creditAccountName == null) ? 0 : creditAccountName
						.hashCode());
		result = prime * result + creditCardCode;
		result = prime * result
				+ ((creditCardName == null) ? 0 : creditCardName.hashCode());
		result = prime * result + creditCardNoOfDigits;
		result = prime * result + creditCardSubTypeCode;
		result = prime
				* result
				+ ((creditCardSubTypeName == null) ? 0 : creditCardSubTypeName
						.hashCode());
		result = prime * result
				+ ((narration == null) ? 0 : narration.hashCode());
		result = prime * result
				+ ((originalAmt == null) ? 0 : originalAmt.hashCode());
		result = prime * result + paymentType;
		result = prime * result
				+ ((paymentTypeName == null) ? 0 : paymentTypeName.hashCode());
		result = prime * result + referencePersonCode;
		result = prime
				* result
				+ ((referencePersonName == null) ? 0 : referencePersonName
						.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentDetailsVm other = (PaymentDetailsVm) obj;
		if (amount == null) {
			if (other.amount != null)
				return false;
		} else if (!amount.equals(other.amount))
			return false;
		if (authorizationNo == null) {
			if (other.authorizationNo != null)
				return false;
		} else if (!authorizationNo.equals(other.authorizationNo))
			return false;
		if (cardChargesAmount == null) {
			if (other.cardChargesAmount != null)
				return false;
		} else if (!cardChargesAmount.equals(other.cardChargesAmount))
			return false;
		if (cardChargesPercentage == null) {
			if (other.cardChargesPercentage != null)
				return false;
		} else if (!cardChargesPercentage.equals(other.cardChargesPercentage))
			return false;
		if (cardNo == null) {
			if (other.cardNo != null)
				return false;
		} else if (!cardNo.equals(other.cardNo))
			return false;
		if (creditAccountCode != other.creditAccountCode)
			return false;
		if (creditAccountName == null) {
			if (other.creditAccountName != null)
				return false;
		} else if (!creditAccountName.equals(other.creditAccountName))
			return false;
		if (creditCardCode != other.creditCardCode)
			return false;
		if (creditCardName == null) {
			if (other.creditCardName != null)
				return false;
		} else if (!creditCardName.equals(other.creditCardName))
			return false;
		if (creditCardNoOfDigits != other.creditCardNoOfDigits)
			return false;
		if (creditCardSubTypeCode != other.creditCardSubTypeCode)
			return false;
		if (creditCardSubTypeName == null) {
			if (other.creditCardSubTypeName != null)
				return false;
		} else if (!creditCardSubTypeName.equals(other.creditCardSubTypeName))
			return false;
		if (narration == null) {
			if (other.narration != null)
				return false;
		} else if (!narration.equals(other.narration))
			return false;
		if (originalAmt == null) {
			if (other.originalAmt != null)
				return false;
		} else if (!originalAmt.equals(other.originalAmt))
			return false;
		if (paymentType != other.paymentType)
			return false;
		if (paymentTypeName == null) {
			if (other.paymentTypeName != null)
				return false;
		} else if (!paymentTypeName.equals(other.paymentTypeName))
			return false;
		if (referencePersonCode != other.referencePersonCode)
			return false;
		if (referencePersonName == null) {
			if (other.referencePersonName != null)
				return false;
		} else if (!referencePersonName.equals(other.referencePersonName))
			return false;
		return true;
	}

}
