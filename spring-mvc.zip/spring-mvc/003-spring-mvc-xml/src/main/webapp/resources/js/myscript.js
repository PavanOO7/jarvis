alert(" Hello  from java script");



function printConsole(){
	console.log(" hello to console");
}