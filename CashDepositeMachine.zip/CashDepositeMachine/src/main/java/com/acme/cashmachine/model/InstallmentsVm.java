package com.acme.cashmachine.model;

import java.util.List;

public class InstallmentsVm 
{
	private int customerCode;
	private int schemeCode;
	private double amount;
	private String date;
	private String narration;
	private String salesmanName;
	private String orderNo;
	private int noOfInstallment;

	private List<PaymentDetailsVm> paymentDetails;
	public int getSchemeCode() {
		return schemeCode;
	}

	public void setSchemeCode(int schemeCode) {
		this.schemeCode = schemeCode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getSalesmanName() {
		return salesmanName;
	}

	public void setSalesmanName(String salesmanName) {
		this.salesmanName = salesmanName;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public int getNoOfInstallment() {
		return noOfInstallment;
	}

	public void setNoOfInstallment(int noOfInstallment) {
		this.noOfInstallment = noOfInstallment;
	}

	

public int getCustomerCode() {
	return customerCode;
}

public void setCustomerCode(int customerCode) {
	this.customerCode = customerCode;
}

public List<PaymentDetailsVm> getPaymentDetails() {
	return paymentDetails;
}

public void setPaymentDetails(List<PaymentDetailsVm> paymentDetails) {
	this.paymentDetails = paymentDetails;
}

}
