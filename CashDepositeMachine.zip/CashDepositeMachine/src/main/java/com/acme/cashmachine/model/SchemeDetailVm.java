package com.acme.cashmachine.model;

public class SchemeDetailVm 
{
	private int minInstammentAmt;
	private int installmentMultipleOf;
    private int allowVariableAmt;
	public int getMinInstammentAmt() {
		return minInstammentAmt;
	}
	public void setMinInstammentAmt(int minInstammentAmt) {
		this.minInstammentAmt = minInstammentAmt;
	}
	public int getInstallmentMultipleOf() {
		return installmentMultipleOf;
	}
	public void setInstallmentMultipleOf(int installmentMultipleOf) {
		this.installmentMultipleOf = installmentMultipleOf;
	}
	public int getAllowVariableAmt() {
		return allowVariableAmt;
	}
	public void setAllowVariableAmt(int allowVariableAmt) {
		this.allowVariableAmt = allowVariableAmt;
	}
}
