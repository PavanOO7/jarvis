/*-
 *  File    :   PersonService.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.raviraj.sample.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.raviraj.sample.model.Contact;
import com.raviraj.sample.model.ContactId;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */
@Service
public class ContactService {

    private List<Contact> list = new ArrayList<>();

    {

        for (int i = 0; i < 10; i++) {
            Contact p = new Contact();
            p.setDate(new Date());
            p.setName("Contact-" + i);
            p.setNo(i);
            ContactId contactId = new ContactId();
            contactId.setCompCode(1);
            contactId.setOwnCode(i);
            contactId.setTenantCode(1);
            p.setContactId(contactId);

            list.add(p);
        }
    }

    public Contact getContact(ContactId ContactId) {

        Optional<Contact> p = list.stream()
                .filter(a -> a.getContactId().equals(ContactId)).findFirst();

        return p.isPresent() ? p.get() : null;

    }

}
