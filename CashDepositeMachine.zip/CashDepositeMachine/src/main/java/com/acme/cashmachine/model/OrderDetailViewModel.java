package com.acme.cashmachine.model;

public class OrderDetailViewModel 
{
	 private String docSeries; 
	 
    
	 private  int docNo;
     private  int docMasterCode;
	 private  int ownCode;
	 private  int docDate;
	 private  int personCode;
	 private  int refDocOwnCode;
	 private  int advanceAmount;
	 private  int adjustmentMethod;
	 private  int documentTypeCode;
	 private  int documentMasterCode;
	 private  int dueDate;
	 private  int locationCode1;
	 private  int locationCode2;
	 private  customrDetailsViewModel customerDetails;
	 
	 public customrDetailsViewModel getCustomerDetails() {
		return customerDetails;
	}

	public void setCustomerDetails(customrDetailsViewModel customerDetails) {
		this.customerDetails = customerDetails;
	}

	public int getDocNo() {
		return docNo;
	}

	public void setDocNo(int docNo) {
		this.docNo = docNo;
	}

	public int getDocMasterCode() {
		return docMasterCode;
	}

	public void setDocMasterCode(int docMasterCode) {
		this.docMasterCode = docMasterCode;
	}

	public int getOwnCode() {
		return ownCode;
	}

	public void setOwnCode(int ownCode) {
		this.ownCode = ownCode;
	}

	public int getDocDate() {
		return docDate;
	}

	public void setDocDate(int docDate) {
		this.docDate = docDate;
	}

	public int getPersonCode() {
		return personCode;
	}

	public void setPersonCode(int personCode) {
		this.personCode = personCode;
	}

	public int getRefDocOwnCode() {
		return refDocOwnCode;
	}

	public void setRefDocOwnCode(int refDocOwnCode) {
		this.refDocOwnCode = refDocOwnCode;
	}

	public int getAdvanceAmount() {
		return advanceAmount;
	}

	public void setAdvanceAmount(int advanceAmount) {
		this.advanceAmount = advanceAmount;
	}

	public int getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(int documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public int getDocumentMasterCode() {
		return documentMasterCode;
	}

	public void setDocumentMasterCode(int documentMasterCode) {
		this.documentMasterCode = documentMasterCode;
	}

	public int getDueDate() {
		return dueDate;
	}

	public void setDueDate(int dueDate) {
		this.dueDate = dueDate;
	}

	public int getLocationCode1() {
		return locationCode1;
	}

	public void setLocationCode1(int locationCode1) {
		this.locationCode1 = locationCode1;
	}

	public int getLocationCode2() {
		return locationCode2;
	}

	public void setLocationCode2(int locationCode2) {
		this.locationCode2 = locationCode2;
	}

	
	
	

	public String getDocSeries() {
		return docSeries;
	}

	public void setDocSeries(String docSeries) {
		this.docSeries = docSeries;
	}

}
