package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

public interface GetDataFromDBService
{
	public Map<String, Object> getOrderDetails(String orderNo) throws Exception;
	public Map<String, Object> getDocNo(int documentMasterCode);
	public int getDateTime(String date1);
	public int getOwnCodeForDMN() throws ClassNotFoundException, SQLException;
	public int getOwnCodeForAccountsTable() throws ClassNotFoundException, SQLException;
	public int getTodaysRate(int date);
	public void getSchemeDetails(String ownCode);
	public int getRecordFromDocMasterTable(int documentmasterCode);
	public int installmentNumber(int ownCode,int amount) throws SQLException;
	public String getDdMmYyDate(int docDate);
	public int getNoOfMonths(int schemeCode) throws ClassNotFoundException, SQLException;
	public Map<String, Object> allowVariableInstallmntAmount(int schemeCode) throws ClassNotFoundException, SQLException;
	public int getInstallmentCount(int refDocNo) throws ClassNotFoundException, SQLException;
	public int getUser() throws ClassNotFoundException, SQLException;
	public int getMaturitydate(int ownCode) throws ClassNotFoundException, SQLException, ParseException;
	public String dateConversionforClarion(String date);
	public int todaysGetDateTime();
	public long getClarionTime();
	BigDecimal getInstallmentAmount(int refDocNo) throws ClassNotFoundException, SQLException;
}
