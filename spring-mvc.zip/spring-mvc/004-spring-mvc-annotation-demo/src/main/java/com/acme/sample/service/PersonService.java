/*-
 *  File    :   PersonService.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.sample.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.acme.sample.model.Person;
import com.acme.sample.model.PersonId;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */
@Service
public class PersonService {

    private List<Person> list = new ArrayList<>();

    {

        for (int i = 0; i < 10; i++) {
            Person p = new Person();
            p.setDate(new Date());
            p.setName("Person-" + i);
            p.setNo(i);
            PersonId personId = new PersonId();
            personId.setCompCode(1);
            personId.setOwnCode(i);
            personId.setTenantCode(1);
            p.setPersonId(personId);

            list.add(p);
        }
    }

    @Cacheable(cacheNames = "myPersoncache")
    public Person getPerson(PersonId personId) {

        System.out.println("PersonService::getPerson() called with   "
                + personId);

        Optional<Person> p = list.stream()
                .filter(a -> a.getPersonId().equals(personId)).findFirst();

        return p.isPresent() ? p.get() : null;

    }

}
