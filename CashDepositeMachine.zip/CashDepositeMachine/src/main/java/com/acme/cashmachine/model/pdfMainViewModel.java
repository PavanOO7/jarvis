package com.acme.cashmachine.model;

public class pdfMainViewModel 
{

	private String printFormat;
	private pdfViewModel param;
	
	public String getPrintFormat() {
		return printFormat;
	}
	public void setPrintFormat(String printFormat) {
		this.printFormat = printFormat;
	}
	public pdfViewModel getParam() {
		return param;
	}
	public void setParam(pdfViewModel param) {
		this.param = param;
	}
}
