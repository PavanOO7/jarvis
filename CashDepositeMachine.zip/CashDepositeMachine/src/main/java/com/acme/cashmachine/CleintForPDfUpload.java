package com.acme.cashmachine;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Properties;
 
public class CleintForPDfUpload
{
 
    private static Socket socket;
    Properties configFile;
    public void readDataFromCOnfigFile()
    {
 	configFile = new java.util.Properties();
 		try 
 		{
 			configFile.load(this.getClass().getClassLoader().
 		    getResourceAsStream("Server_Data.config"));
 			String hostAddress = this.configFile.getProperty("HOST_ADDRESS");
 			String portNo = this.configFile.getProperty("PORT_NO");
 			System.out.println("value >> "+hostAddress);
 			System.out.println("value1 >> "+portNo);
 			connectToClient(hostAddress,Integer.parseInt(portNo));
 		}
 		catch(Exception eta)
 		{
 			eta.printStackTrace();
 		}
     }

    public void connectToClient(String hostAddress,int portNo)
    {
    	try
        {
            // String host = "172.16.2.36";
            String host = hostAddress;   //Print Server ip
            int port = portNo;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket(address, port);
 
            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
 
            // String number = "38860";
            String number = " 1       38772    12Microsoft XPS Document Writer";
 
            String sendMessage = number + "\n";
            bw.write(sendMessage);
            bw.flush();
            System.out.println("Message sent to the server : "+sendMessage);
 
            //Get the return message from the server
            InputStream is = socket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String message = br.readLine();
            System.out.println("Message received from the server : " +message);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
        finally
        {
            //Closing the socket
            try
            {
                socket.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
 
    public static void main(String args[])
    {
        
    }
}