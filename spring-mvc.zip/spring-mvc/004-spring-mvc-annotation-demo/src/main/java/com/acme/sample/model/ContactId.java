/*-
 *  File    :   AddressId.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.sample.model;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */
public class ContactId {

    private int compCode;

    private int tenantCode;

    private int ownCode;

    public int getCompCode() {
        return compCode;
    }

    public void setCompCode(int compCode) {
        this.compCode = compCode;
    }

    public int getTenantCode() {
        return tenantCode;
    }

    public void setTenantCode(int tenantCode) {
        this.tenantCode = tenantCode;
    }

    public int getOwnCode() {
        return ownCode;
    }

    public void setOwnCode(int ownCode) {
        this.ownCode = ownCode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + compCode;
        result = prime * result + ownCode;
        result = prime * result + tenantCode;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ContactId other = (ContactId) obj;
        if (compCode != other.compCode)
            return false;
        if (ownCode != other.ownCode)
            return false;
        if (tenantCode != other.tenantCode)
            return false;
        return true;
    }

}
