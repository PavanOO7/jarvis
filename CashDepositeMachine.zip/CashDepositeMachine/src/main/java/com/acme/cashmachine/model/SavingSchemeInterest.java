/*-
 *  File    :   SavingSchemeInterest.java
 *  Version :   1.0
 *  Date    :   Apr 2, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.cashmachine.model;


import java.util.ArrayList;
import java.util.List;


/**
 * @author
 * @date Apr 1, 2016
 * @since 1.0
 */
public class SavingSchemeInterest {

    private double totalBenefit;
    private double totalAdvance;
    private double totalMetal;
    private double avgRate;

    private List<DailyInterestRate> dailyInterestRates = new ArrayList<DailyInterestRate>();

    /**
     * @return the totalBenefit
     */
    public double getTotalBenefit() {
        return totalBenefit;
    }

    /**
     * @param totalBenefit
     *            the totalBenefit to set
     */
    public void setTotalBenefit(double totalBenefit) {
        this.totalBenefit = totalBenefit;
    }

    /**
     * @return the dailyInterestRates
     */
    public List<DailyInterestRate> getDailyInterestRates() {
        return dailyInterestRates;
    }

    /**
     * @param dailyInterestRates
     *            the dailyInterestRates to set
     */
    public void setDailyInterestRates(List<DailyInterestRate> dailyInterestRates) {
        this.dailyInterestRates = dailyInterestRates;
    }

    /**
     * @return the totalAdvance
     */
    public double getTotalAdvance() {
        return totalAdvance;
    }

    /**
     * @param totalAdvance
     *            the totalAdvance to set
     */
    public void setTotalAdvance(double totalAdvance) {
        this.totalAdvance = totalAdvance;
    }

    /**
     * @return the totalMetal
     */
    public double getTotalMetal() {
        return totalMetal;
    }

    /**
     * @param totalMetal
     *            the totalMetal to set
     */
    public void setTotalMetal(double totalMetal) {
        this.totalMetal = totalMetal;
    }

    /**
     * @return the avgRate
     */
    public double getAvgRate() {
        return avgRate;
    }

    /**
     * @param avgRate
     *            the avgRate to set
     */
    public void setAvgRate(double avgRate) {
        this.avgRate = avgRate;
    }

}
