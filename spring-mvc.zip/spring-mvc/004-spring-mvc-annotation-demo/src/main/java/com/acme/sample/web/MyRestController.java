/*-
 *  File    :   MyController.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.sample.web;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acme.sample.model.Address;
import com.acme.sample.model.AddressId;
import com.acme.sample.model.Contact;
import com.acme.sample.model.ContactId;
import com.acme.sample.model.Person;
import com.acme.sample.model.PersonId;
import com.acme.sample.service.AddressService;
import com.acme.sample.service.ContactService;
import com.acme.sample.service.PersonService;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */

@RestController
public class MyRestController {

    @Autowired
    private PersonService personServcice;

    @Autowired
    private AddressService addressService;

    @Autowired
    private ContactService contactService;

    @RequestMapping(name = "/test1")
    public String test1() {

        return "Hello World";
    }

    @RequestMapping(value = "/person/{id}")
    public Person getPerson(@PathVariable Integer id) {

        PersonId personId = new PersonId();
        personId.setCompCode(1);
        personId.setTenantCode(1);
        personId.setOwnCode(id);
        return personServcice.getPerson(personId);
    }

    @RequestMapping(value = "/address/{id}")
    public Address getAddress(@PathVariable Integer id) {

        AddressId addressId = new AddressId();
        addressId.setCompCode(1);
        addressId.setTenantCode(1);
        addressId.setOwnCode(id);
        return addressService.getAddress(addressId);
    }

    @RequestMapping(value = "/contact/{id}")
    public Contact getContact(@PathVariable Integer id) {

        ContactId contactId = new ContactId();
        contactId.setCompCode(1);
        contactId.setTenantCode(1);
        contactId.setOwnCode(id);
        return contactService.getContact(contactId);
    }

}
