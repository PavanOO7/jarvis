/**
 *
 */
package com.acme.cashmachine.model;

import com.acme.cashmachine.model.OrderComponentMainViewModel;

/**
 * @author Mahesh S. Nikam
 * @date Jan 18, 2018
 */
public class CustomerSchemeOutputVm {
	private int errorCode;
	private String errorMsg;
	private OrderComponentMainViewModel result;

	/**
	 *
	 */
	public CustomerSchemeOutputVm() {
		this.errorCode = 0;
		this.errorMsg = "";
		this.result = new OrderComponentMainViewModel();
	}

	/**
	 * @return the errorCode
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the result
	 */
	public OrderComponentMainViewModel getResult() {
		return result;
	}

	/**
	 * @param result
	 *            the result to set
	 */
	public void setResult(OrderComponentMainViewModel result) {
		this.result = result;
	}

}
