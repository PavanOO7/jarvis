package com.acme.cashmachine;

import java.sql.SQLException;
import java.util.List;

import com.acme.cashmachine.model.SchemeOrderDetailsModel;

public interface GetDataFromDbForGetOrderDetailsController 
{
	public List<SchemeOrderDetailsModel> getSchemeOrderDetails(int ownCode) throws ClassNotFoundException, SQLException;

}
