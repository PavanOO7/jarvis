package com.acme.cashmachine;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acme.cashmachine.model.pdfMainViewModel;
import com.acme.cashmachine.model.pdfViewModel;

@RestController
public class sendPdfController 
{
	
	private GetDataFromDbForPdf getDataFromDbForPdf;
	
	@Autowired
	sendPdfController(GetDataFromDbForPdf getDataFromDbForPdf)
	{
		this.getDataFromDbForPdf = getDataFromDbForPdf;
	}
	
	@RequestMapping(value = "/scm/v1/scheme/4", method = RequestMethod.POST)
	public void orderDetails(@RequestBody  pdfMainViewModel pdfMainViewModel,HttpServletRequest request,HttpServletResponse response) throws Exception 
	{						
		if(pdfMainViewModel == null)
		{
			throw new Exception("Please provide Inputs");
		} 
		
		if(pdfMainViewModel.getParam() == null || pdfMainViewModel.getParam().equals(""))
		{	 
		    throw new Exception("Please provide Valid Inputs");	  
		}
		
		if(pdfMainViewModel.getParam().getDocumentOwnCode()==0)
		{	 
			throw new Exception("Please provide Valid Document OwnCode");  
		}
		
		int ownCode  = pdfMainViewModel.getParam().getDocumentOwnCode();
		//System.out.println("ownCode :: "+ownCode);
		Map<String,Object> configFileData = getDataFromDbForPdf.readDataFromCOnfigFile();
		String hostAddress = (String) configFileData.get("hostAddress");
		String ftpAddress = (String) configFileData.get("ftpAddress");
		String userName = (String) configFileData.get("userName");
		String password = (String) configFileData.get("password");
		int portNo = Integer.valueOf(configFileData.get("portNo").toString());
		int flag = getDataFromDbForPdf.connectToClientAndUploadFileToFtp(ownCode,hostAddress,portNo);
		//System.out.println("hostAddress >> "+ hostAddress +" portNo >> "+portNo);
		//System.out.println("flag :: "+flag);
		
		if (flag == 1)
		{
			String PdfName = getDataFromDbForPdf.getDataFromFtpDataTable(ownCode);
/*		       System.out.println("Working Directory = " +
		               System.getProperty("os.name"));
*/			TimeUnit.SECONDS.sleep(10);
			try
			{		try
				{
					if (PdfName == null || PdfName.equals(""))
					{					 
						 PdfName = getDataFromDbForPdf.getDataFromFtpDataTable(ownCode);
					}
				}
			catch(Exception e)
			{
				throw new Exception("Provided owncode is invalid : "+e);
			}
			
					if (!PdfName.equals(""))
					{
						try
					    {							
							//System.out.println("ftpAddress >> "+ftpAddress+" userName  >> "+ userName +" password >> "+password);
					    	DownloadPdfFromServer DownloadPdfFromServer=new DownloadPdfFromServer();
						    DownloadPdfFromServer.downloadPdfFromServer(ftpAddress, userName, password ,PdfName);
				            if (DownloadPdfFromServer != null )
				            {
				            	File file = null;
				            	String TempFileDirectory = null;
				    	        // FileInputStream fileStream = new FileInputStream(file = new File("C:\\AcmeTmpFiles\\a\\"+PdfName));
				            	String osName = System.getProperty("os.name");
				            	if (osName.contains("W"))
				            	{
				            		 TempFileDirectory = "\\files\\";
				            	}
				            	else
				            	{
				            		 TempFileDirectory = "//files//";
				            	}
				            	
				            	FileInputStream fileStream = new FileInputStream(file = new File(System.getProperty("user.dir").trim() + TempFileDirectory.trim() +PdfName));
				            	//FileInputStream fileStream = new FileInputStream(file = new File(System.getProperty("user.dir") + "\\files\\" +PdfName));
				    	        byte[] arr = new byte[(int) file.length()];
				    	        fileStream.read(arr, 0, arr.length);
				    	        response.setContentType("application/pdf");
				    	        response.setHeader("Content-disposition", "attachment; filename=" + file.getName());
				    	        response.setContentLength(arr.length);
				    	        response.getOutputStream().write(arr);
				    	        response.getOutputStream().flush();
				    	        fileStream.close();
				            }
					    }
					    catch(Exception e)
					    {
					    	throw new Exception("Provided owncode is invalid : "+e);
					    }
				  	    //DownloadPdfFromServer DownloadPdfFromServer=new DownloadPdfFromServer("172.16.2.114", "vrm", "vrm");
			  	    }
					else
					{
						throw new Exception("Provided owncode is invalid");
					}
				
			}
			catch(Exception e)
			{
				throw new Exception("Provided owncode is invalid.");
			}
		}
		else
		{
			throw new Exception("Cannot connect to Ftp Server");
		}			
    }			
}
