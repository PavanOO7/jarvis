/*-
 *  File    :   HomeService.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.raviraj.sample.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.raviraj.sample.model.Address;
import com.raviraj.sample.model.AddressId;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */
@Service
public class AddressService {

    private List<Address> list = new ArrayList<>();

    {

        for (int i = 0; i < 10; i++) {
            Address p = new Address();
            p.setDate(new Date());
            p.setName("Address-" + i);
            p.setNo(i);
            AddressId add = new AddressId();
            add.setCompCode(1);
            add.setOwnCode(i);
            add.setTenantCode(1);
            p.setAddressId(add);

            list.add(p);
        }
    }

    public Address getAddress(AddressId addressId) {

        Optional<Address> p = list.stream()
                .filter(a -> a.getAddressId().equals(addressId)).findFirst();

        return p.isPresent() ? p.get() : null;

    }

}
