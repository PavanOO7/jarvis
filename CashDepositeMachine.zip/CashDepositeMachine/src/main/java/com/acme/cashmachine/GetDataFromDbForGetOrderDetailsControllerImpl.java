package com.acme.cashmachine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acme.cashmachine.model.DatabaseConnectionService;
import com.acme.cashmachine.model.GetDataFromDBService;
import com.acme.cashmachine.model.SchemeOrderDetailsModel;

@Service
public class GetDataFromDbForGetOrderDetailsControllerImpl implements GetDataFromDbForGetOrderDetailsController
{
	private GetDataFromDBService getDataFromDbService;	
	
	@Autowired
	GetDataFromDbForGetOrderDetailsControllerImpl(GetDataFromDBService getDataFromDbService)
	{
		this.getDataFromDbService = getDataFromDbService;
	}
	
	@Override
	public List<SchemeOrderDetailsModel> getSchemeOrderDetails(int ownCode) throws ClassNotFoundException, SQLException
	{
		   SchemeOrderDetailsModel schemeOrderDetailsModel = new SchemeOrderDetailsModel();
		   List<SchemeOrderDetailsModel> schemeOrderDetailsList = new ArrayList<SchemeOrderDetailsModel>();
		   String docDate1 = null;
	       Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE CompCode=1 AND RefDocOwnCode= "+ownCode+" or OwnCode= "+ownCode+"");
		   try
		   {
			while(rs.next())
         	 {
				schemeOrderDetailsModel = new SchemeOrderDetailsModel();
				schemeOrderDetailsModel.setAdvance(rs.getBigDecimal("advanceAmount"));
				schemeOrderDetailsModel.setInstallmentAmount(rs.getBigDecimal("advanceAmount"));
				schemeOrderDetailsModel.setVoucherOwncode(rs.getLong("refDocOwnCode"));
				schemeOrderDetailsModel.setOwnCode(rs.getInt("ownCode"));
				schemeOrderDetailsModel.setVoucherNo(rs.getString("Series")+"-"+rs.getInt("docNo"));
				schemeOrderDetailsModel.setCancelflag(rs.getInt("CancelFlag"));
				schemeOrderDetailsModel.setDocumentOwnCode(rs.getInt("refDocOwnCode"));
				int docDate = rs.getInt("docDate");
				docDate1 = getDataFromDbService.getDdMmYyDate(docDate);
				schemeOrderDetailsModel.setDate(docDate1);
				schemeOrderDetailsList.add(schemeOrderDetailsModel);
				//return schemeOrderDetailsList;
         	 }			
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
		   con11.close();
		   return schemeOrderDetailsList;
	}
	

}
