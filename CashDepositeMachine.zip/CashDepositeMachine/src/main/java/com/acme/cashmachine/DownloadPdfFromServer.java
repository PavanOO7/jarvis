package com.acme.cashmachine;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

public class DownloadPdfFromServer
{
    FTPClient ftp = null;

    public int  downloadPdfFromServer(String host, String user, String pwd,String pdfName) throws Exception 
    {
        ftp = new FTPClient();
        ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
        int reply;
        ftp.connect(host);
        reply = ftp.getReplyCode();
        if (!FTPReply.isPositiveCompletion(reply)) 
        {
            ftp.disconnect();
            throw new Exception("Exception in connecting to FTP Server");
        }
        ftp.login(user, pwd);
        ftp.setFileType(FTP.BINARY_FILE_TYPE);
        ftp.enterLocalPassiveMode();
        try 
        {
  /*      	DownloadPdfFromServer ftpDownloader =
                new DownloadPdfFromServer("172.16.2.114", "vrm", "vrm");*/
            //downloadFile("/Acme-Padm/"+pdfName, "C:\\AcmeTmpFiles\\a\\"+pdfName);
        	//String TempFileDirectory = "\\files\\";
        	String osName = System.getProperty("os.name");
        	String TempFileDirectory = null;
        	//System.out.println("aaa >>> "+System.getProperty("user.dir"));
        	File dir = new File(System.getProperty("user.dir").trim()+"/files");
                     
            try
            {
            	  boolean successful = dir.mkdir();
            }
            catch(Exception e)
            {
            	throw new Exception("Error while creating directory : "+e);
            }
            //System.out.println("successful >> "+successful);
        	if (osName.contains("W"))
        	{
        		 TempFileDirectory = "\\files\\";
        	}
        	else
        	{
        		 TempFileDirectory = "//files//";
        	}
        	downloadFile("/Acme-Padm/"+pdfName, System.getProperty("user.dir").trim() + TempFileDirectory.trim() +pdfName);
            
            //System.out.println("FTP File downloaded successfully");
            disconnect();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
		return reply;
    }

    public void downloadFile(String remoteFilePath, String localFilePath) 
    {
        try (FileOutputStream fos = new FileOutputStream(localFilePath)) 
        {
            this.ftp.retrieveFile(remoteFilePath, fos);
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    public void disconnect() 
    {
        if (this.ftp.isConnected()) 
        {
            try 
            {
                this.ftp.logout();
                this.ftp.disconnect();
            } 
            catch (IOException f) 
            {
             
            }
        }
    }

   /* public static void main(String[] args) 
    {
        try 
        {
        	DownloadPdfFromServer ftpDownloader =
                new DownloadPdfFromServer("172.16.2.114", "vrm", "vrm");
            ftpDownloader.downloadFile("/Acme-Padm/123.txt", "D:\\123.txt");
            System.out.println("FTP File downloaded successfully");
            ftpDownloader.disconnect();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }*/
}