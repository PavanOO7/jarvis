package com.acme.cashmachine.model;

public class GetDocNo
{
	private int documentNo;
	private String seriesFromAutoNoTable;
	public int getDocumentNo() {
		return documentNo;
	}
	public void setDocumentNo(int documentNo) {
		this.documentNo = documentNo;
	}
	public String getSeriesFromAutoNoTable() {
		return seriesFromAutoNoTable;
	}
	public void setSeriesFromAutoNoTable(String seriesFromAutoNoTable) {
		this.seriesFromAutoNoTable = seriesFromAutoNoTable;
	}

}
