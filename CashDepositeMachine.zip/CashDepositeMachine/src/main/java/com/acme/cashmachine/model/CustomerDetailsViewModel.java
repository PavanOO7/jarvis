/*-
 *  File    :   CustomerDetailsViewModel.java
 *  Version :   1.0
 *  Date    :   Feb 19, 2016
 *  Author  :   Monika
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class CustomerDetailsViewModel {

	/**
	 * Represents customer owncode
	 */
	private long code;

	/**
	 * Represents customer name
	 */
	private String name;

	/**
	 * Represents address
	 */
	private String addressLine1;

	/**
	 * Represents address
	 */
	private String addressLine2;

	/**
	 * Represents phone no
	 */
	private String phoneNo;

	/**
	 * Represents mobile No
	 */
	private long mobileNo;

	/**
	 * Represents city
	 */
	private String city;

	/**
	 * Represents area
	 */
	private String area;

	private String pinCode;
	private String panNo;

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public long getCode() {
		return code;
	}

	/**
	 *
	 * @param code
	 */
	public void setCode(long code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	/**
	 *
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 *
	 * @param addressLine1
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 *
	 * @param addressLine2
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 *
	 * @param phoneNo
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	/**
	 *
	 * @param mobileNo
	 */
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCity() {
		return city;
	}

	/**
	 *
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	/**
	 *
	 * @param area
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the pinCode
	 */
	public String getPinCode() {
		return pinCode;
	}

	/**
	 * @param pinCode
	 *            the pinCode to set
	 */
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

}
