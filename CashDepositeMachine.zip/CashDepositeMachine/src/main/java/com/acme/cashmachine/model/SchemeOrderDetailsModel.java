/*-
 *  File    :   SchemeOrderDetailsModel.java
 *  Version :   1.0
 *  Date    :   Apr 16, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */

package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author
 * @date Feb 18, 2016
 * @since 1.0
 */
public class SchemeOrderDetailsModel {

	/**
	 * Represents owncode of scheme Ledger Document
	 */
	private long ownCode;

	/**
	 * Represents date of scheme Order Document
	 */
	private String date;

	/**
	 * Represents Docno of scheme Order Document
	 */
	private String voucherNo;

	/**
	 * Represents owncode of scheme Order Document
	 */
	private long voucherOwncode;

	/**
	 * Represents advance amount [+ For Jama and - For Return]
	 */
	private BigDecimal advance;

	/**
	 * Represents metal Qty [+ For Jama and - For Return]
	 */
	private BigDecimal metal;

	/**
	 * Represents metalBooked [+ For Jama and - For Return]
	 */
	private BigDecimal metalBooked;

	/**
	 * Represents purity
	 */
	private BigDecimal purity;

	/**
	 * Represents rate
	 */
	private BigDecimal rate;

	/**
	 * Represents How May Days Installment Was Late
	 */
	private int lateDays;

	/**
	 * Represent document was installment or return
	 */
	private boolean returned;

	/**
	 * Represent document is cancelled or not
	 */
	private int cancelflag;
	private int month;
	/**
	 * Represents Fine Or Charges
	 */
	private BigDecimal otherCharges;

	private byte transactionType;

	private BigDecimal installmentAmount;

	/**
	 * Represents document Own Code
	 */
	private long documentOwnCode;

	private BigDecimal tax;
	private BigDecimal taxOnAdvance;
	private BigDecimal inclusiveAdvance;
	// newly added By Mahesh 22.02.2018 to Get Year
	private int year;

	private BigDecimal benefitValue;

	private BigDecimal benefitPoint;

	public BigDecimal getTaxOnAdvance() {
		return taxOnAdvance;
	}

	public void setTaxOnAdvance(BigDecimal taxOnAdvance) {
		this.taxOnAdvance = taxOnAdvance;
	}

	public byte getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(byte transactionType) {
		this.transactionType = transactionType;
	}

	public boolean isReturned() {
		return returned;
	}

	public void setReturned(boolean returned) {
		this.returned = returned;
	}

	public int isCancelflag() {
		return cancelflag;
	}

	public void setCancelflag(int i) {
		this.cancelflag = i;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getDate() {
		return date;
	}

	/**
	 *
	 * @param docDate1
	 */
	public void setDate(String docDate1) {
		this.date = docDate1;
	}

	public String getVoucherNo() {
		return voucherNo;
	}

	/**
	 *
	 * @param voucherNo
	 */
	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public long getVoucherOwncode() {
		return voucherOwncode;
	}

	/**
	 *
	 * @param voucherOwncode
	 */
	public void setVoucherOwncode(long voucherOwncode) {
		this.voucherOwncode = voucherOwncode;
	}

	public BigDecimal getAdvance() {
		return advance;
	}

	/**
	 *
	 * @param advance
	 */
	public void setAdvance(BigDecimal advance) {
		this.advance = advance;
	}

	public BigDecimal getMetal() {
		return metal;
	}

	/**
	 *
	 * @param metal
	 */
	public void setMetal(BigDecimal metal) {
		this.metal = metal;
	}

	public BigDecimal getMetalBooked() {
		return metalBooked;
	}

	/**
	 *
	 * @param metalBooked
	 */
	public void setMetalBooked(BigDecimal metalBooked) {
		this.metalBooked = metalBooked;
	}

	public BigDecimal getPurity() {
		return purity;
	}

	/**
	 *
	 * @param purity
	 */
	public void setPurity(BigDecimal purity) {
		this.purity = purity;
	}

	public BigDecimal getRate() {
		return rate;
	}

	/**
	 *
	 * @param rate
	 */
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public int getLateDays() {
		return lateDays;
	}

	/**
	 *
	 * @param lateDays
	 */
	public void setLateDays(int lateDays) {
		this.lateDays = lateDays;
	}

	public BigDecimal getOtherCharges() {
		return otherCharges;
	}

	/**
	 *
	 * @param otherCharges
	 */
	public void setOtherCharges(BigDecimal otherCharges) {
		this.otherCharges = otherCharges;
	}

	public long getOwnCode() {
		return ownCode;
	}

	/**
	 *
	 * @param ownCode
	 */
	public void setOwnCode(long ownCode) {
		this.ownCode = ownCode;
	}

	public BigDecimal getInstallmentAmount() {
		return installmentAmount;
	}

	public void setInstallmentAmount(BigDecimal installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	public long getDocumentOwnCode() {
		return documentOwnCode;
	}

	public void setDocumentOwnCode(long documentOwnCode) {
		this.documentOwnCode = documentOwnCode;
	}

	public BigDecimal getTax() {
		return tax;
	}

	public void setTax(BigDecimal tax) {
		this.tax = tax;
	}

	public BigDecimal getInclusiveAdvance() {
		return inclusiveAdvance;
	}

	public void setInclusiveAdvance(BigDecimal inclusiveAdvance) {
		this.inclusiveAdvance = inclusiveAdvance;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	public BigDecimal getBenefitValue() {
		return benefitValue;
	}

	public void setBenefitValue(BigDecimal benefitValue) {
		this.benefitValue = benefitValue;
	}

	public BigDecimal getBenefitPoint() {
		return benefitPoint;
	}

	public void setBenefitPoint(BigDecimal benefitPoint) {
		this.benefitPoint = benefitPoint;
	}

}
