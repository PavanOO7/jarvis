package com.acme.cashmachine.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UpdateTableData 
{
	DatabaseConnectionService databaseConnectionService =new DatabaseConnectionService();
	Connection con = databaseConnectionService.databaseConnectionMethod();	   
	
	public void updateAutoNoTable(int count,int ownCode,String series) throws ClassNotFoundException, SQLException
	{
	    Connection con11=null;
		if (count != 0)
		 {
			try
			 {
			   //Class.forName("com.mysql.jdbc.Driver");			 
			   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
				Class.forName("com.mysql.jdbc.Driver");
			   
			       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

			   java.sql.Statement stmt1=con11.createStatement();		
			   int cnt=0;					 			
			   cnt=stmt1.executeUpdate("UPDATE AutoNoTable SET owncode= "+ownCode+" WHERE series='"+series+"'");
			   //System.out.println("Executed 3");
			 }
			   catch(Exception e)
		     {
			   	System.out.println("Error while updating updateAutoNoTable : "+e);
			 }
			con11.close();
		 }
	}
	
	public void updateAutoNoTableForDoc(int documentNo,int documentMasterCode) throws Exception
	{
		   Connection con11=null;
		try		
		{		
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		    
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();
		   int rs = 0;    	    
		   rs=stmt1.executeUpdate("UPDATE AutoNoTableForDocument SET DocNo = "+documentNo+" WHERE DocumentMasterCode= "+documentMasterCode+" ");	   
		   if (rs == 0)	
		   {
			   throw new Exception("Error while Updating AutoNoTableForDocument Record ");
		   } 
		  
		}
		catch(Exception e)
		{			
			throw new Exception("Error while ie Updating AutoNoTableForDocument Record  : "+e.getMessage());
		}   
		
		finally
		{
			con11.close();
		}
	}

	
	
}
