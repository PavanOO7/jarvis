/*-
 *  File    :   DailyInterestRate.java
 *  Version :   1.0
 *  Date    :   Apr 2, 2016
 *  Author  :   Samvedna
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.cashmachine.model;




/**
 * @author
 * @date Apr 1, 2016
 * @since 1.0
 */
public class DailyInterestRate {

    private String docDate;
    private String docNo;
    private double amount;
    private double balance;
    private double interest;
    private int daysDiff;

    /**
     * @return the docNo
     */
    public String getDocNo() {
        return docNo;
    }

    /**
     * @param docNo
     *            the docNo to set
     */
    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    /**
     * @return the amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * @param amount
     *            the amount to set
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance
     *            the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * @return the interest
     */
    public double getInterest() {
        return interest;
    }

    /**
     * @param interest
     *            the interest to set
     */
    public void setInterest(double interest) {
        this.interest = interest;
    }

    /**
     * @return the daysDiff
     */
    public int getDaysDiff() {
        return daysDiff;
    }

    /**
     * @param daysDiff
     *            the daysDiff to set
     */
    public void setDaysDiff(int daysDiff) {
        this.daysDiff = daysDiff;
    }

    /**
     * @return the docDate
     */
    public String getDocDate() {
        return docDate;
    }

    /**
     * @param docDate
     *            the docDate to set
     */
    public void setDocDate(String docDate) {
        this.docDate = docDate;
    }

}
