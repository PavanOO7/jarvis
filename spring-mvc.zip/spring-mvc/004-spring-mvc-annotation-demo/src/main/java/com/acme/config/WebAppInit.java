/*-
 *  File    :   WebAppInit.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.config;


import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */
public class WebAppInit extends
        AbstractAnnotationConfigDispatcherServletInitializer {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.support.
     * AbstractAnnotationConfigDispatcherServletInitializer
     * #getRootConfigClasses()
     */
    @Override
    protected Class<?>[] getRootConfigClasses() {

        return new Class[] {};
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.support.
     * AbstractAnnotationConfigDispatcherServletInitializer
     * #getServletConfigClasses()
     */
    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class[] { MvcConfig.class };
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.web.servlet.support.AbstractDispatcherServletInitializer
     * #getServletMappings()
     */
    @Override
    protected String[] getServletMappings() {
        return new String[] { "/" };
    }

}
