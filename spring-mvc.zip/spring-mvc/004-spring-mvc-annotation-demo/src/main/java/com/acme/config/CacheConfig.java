/*-
 *  File    :   CacheConfig.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.acme.config;


import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleCacheErrorHandler;
import org.springframework.cache.interceptor.SimpleKeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */

@Configuration
@EnableCaching
public class CacheConfig extends CachingConfigurerSupport {

    @Autowired
    private ServletContext servletContext;

    @Bean(name = "myEhCacheManager", destroyMethod = "shutdown")
    public net.sf.ehcache.CacheManager ehCacheManager() {

        net.sf.ehcache.config.CacheConfiguration cacheConfiguration = new net.sf.ehcache.config.CacheConfiguration();
        cacheConfiguration.setName("myPersoncache");
        cacheConfiguration.setMemoryStoreEvictionPolicy("LRU");
        cacheConfiguration.setMaxEntriesLocalHeap(5);
        cacheConfiguration.setEternal(false);
        // cacheConfiguration.setMaxEntriesInCache(3);
        cacheConfiguration.setOverflowToOffHeap(false);
        cacheConfiguration.setTransactionalMode("OFF");

        net.sf.ehcache.config.CacheConfiguration cacheConfiguration1 = new net.sf.ehcache.config.CacheConfiguration();
        cacheConfiguration1.setName("myContctCache");
        cacheConfiguration1.setMemoryStoreEvictionPolicy("LRU");
        cacheConfiguration1.setMaxEntriesLocalHeap(5);
        // cacheConfiguration1.setMaxEntriesInCache(3);
        cacheConfiguration1.setOverflowToOffHeap(false);
        cacheConfiguration1.setTransactionalMode("OFF");

        net.sf.ehcache.config.Configuration config = new net.sf.ehcache.config.Configuration();
        config.setName("MyCacheManager");
        // if (servletContext != null) {
        // config.setName("MyCacheManager" + "-"
        // + servletContext.getContextPath().substring(1));
        // } else {
        // config.setName("MyCacheManager" + System.currentTimeMillis());
        // }

        config.addCache(cacheConfiguration);
        config.addCache(cacheConfiguration1);

        net.sf.ehcache.CacheManager cachemanager = net.sf.ehcache.CacheManager
                .newInstance(config);

        return cachemanager;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.cache.annotation.CachingConfigurer#cacheManager()
     */
    @Override
    @Bean(name = "myCacheManager")
    public org.springframework.cache.CacheManager cacheManager() {

        return new EhCacheCacheManager(ehCacheManager());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.cache.annotation.CachingConfigurer#keyGenerator()
     */
    @Override
    public KeyGenerator keyGenerator() {

        return new SimpleKeyGenerator();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.cache.annotation.CachingConfigurer#errorHandler()
     */
    @Override
    public CacheErrorHandler errorHandler() {

        return new SimpleCacheErrorHandler();
    }

}
