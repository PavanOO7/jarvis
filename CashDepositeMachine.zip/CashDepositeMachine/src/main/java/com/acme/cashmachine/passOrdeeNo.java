package com.acme.cashmachine;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acme.cashmachine.model.CustomerDetailsViewModel;
import com.acme.cashmachine.model.CustomerSchemeOutputVm;
import com.acme.cashmachine.model.DatabaseConnectionService;
import com.acme.cashmachine.model.OrderComponentMainViewModel;
import com.acme.cashmachine.model.OrderDataViewModel;
import com.acme.cashmachine.model.OrderDetailViewModel;
import com.acme.cashmachine.model.SchemeDataViewModel;
import com.acme.cashmachine.model.SchemeOperationVm;
import com.acme.cashmachine.model.customrDetailsViewModel;
import com.fasterxml.jackson.databind.util.JSONPObject;

@RestController
public class passOrdeeNo 
{
	List<String> seriesDocNoList = new ArrayList<>();
	String series;
	//Connection con=null;
	String docNo,custName,address1,address2,panNo,area,city,phoneNo,pinCode;
	long masterCode,CustMobileNo;
	int branchCode;
	
    String docSeries;
	 int documentNo;
	 int docMasterCode;
	 int ownCode;
	 int docDate;
	 int personCode;
	 int refDocOwnCode;
	 int advanceAmount;
	 int adjustmentMethod;
	 int documentTypeCode;
	 int documentMasterCode;
	 int dueDate;
	 int locationCode1;
	 int locationCode2;
	 String JSONString;
	public  String loc ;
	private DatabaseConnectionService databaseConnectionService;
	void passOrdeeNo(DatabaseConnectionService databaseConnectionService)
	{
		this.databaseConnectionService = databaseConnectionService;
	}
	@RequestMapping(value = "/scm/v1/scheme/399", method = RequestMethod.POST)
	public SchemeOperationVm getOrderDetails(
			@RequestBody String  orderNo) throws Exception 
	{				  
	
		//System.out.println(orderNo);
		DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
        Connection con = databaseConnectionService.databaseConnectionMethod();
        System.out.println("abc >> "+con);
		try{
			   Class.forName("com.mysql.jdbc.Driver");	   			     			 
   			   JSONObject obj=new JSONObject(orderNo);
   			   //String series =  orderNo.replaceAll("[^a-z || A-Z]", "").trim();//numbers2.trim();//seriesDocNoList.get(0);			   
			   //int doc = Integer.parseInt(orderNo.replaceAll("[^0-9]", "").trim());
   			   //System.out.println("value"+obj.get("orderNo").toString());
   			   seriesDocNoList.addAll(Arrays.asList(obj.get("orderNo").toString().split("-")));
   			   //System.out.println("1 .. "+seriesDocNoList.get(0));
   			   //System.out.println("2 ... "+seriesDocNoList.get(1));
   			   //series =  seriesDocNoList.get(0);
   			   docNo  =  seriesDocNoList.get(1);
   			   docNo  =  docNo.trim();
   			   int doc = Integer.parseInt(docNo);	
   			   //System.out.println("series > "+series+"  docNo > "+docNo);
   			   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/PngSons_15March","AcmeInfi","ProteasLankans");	
   			   java.sql.Statement stmt1=con.createStatement();   			   
   			   ResultSet rs;    	    
   			   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE COMPCODE=1 AND DOCUMENTTYPECODE=6 AND DOCUMENTSUBTYPE = 'B' AND DOCNO="+doc+" AND SERIES ='"+series+"'");
   		
   			   	try
   			   		{
   			   			while(rs.next())
   			   				{
   			   					series             =  rs.getString("series");
   			   					documentNo         =  rs.getInt("docNo");
   			   					docMasterCode      =  rs.getInt("documentMasterCode"); 
   			   					ownCode            =  rs.getInt("ownCode"); 
   			   					docDate 	       =  rs.getInt("docDate");
   			   					personCode  	   =  rs.getInt("personCode"); 
   			   					refDocOwnCode      =  rs.getInt("refDocOwnCode"); 
   			   					advanceAmount      =  rs.getInt("advanceAmount");
   			   					adjustmentMethod   =  rs.getInt("adjustmentMethod");
   			   					documentTypeCode   =  rs.getInt("documentTypeCode");
   			   					documentMasterCode =  rs.getInt("documentMasterCode");
   			   					dueDate  		   =  rs.getInt("dueDate");
   			   					locationCode1 	   =  rs.getInt("locationCode1");
   			   					locationCode2 	   =  rs.getInt("locationCode2");    		      
   			   				 }
   			   			//getOrderDetails(orderNo);
   			   			getCustomerDetails(personCode);
   			   			getBranchCode(ownCode);    	
   			   		}
     catch(Exception e)
     {
    	 System.out.println(e);
     }
	     
	 }
		
	catch(Exception e)
		{
		throw new Exception(e.getMessage());
		
		}
		
		SchemeDataViewModel SchemeData=new SchemeDataViewModel();
		OrderDataViewModel orderDataVm=new OrderDataViewModel();		
		CustomerDetailsViewModel cust=new CustomerDetailsViewModel();
		
		OrderComponentMainViewModel orderVm = new OrderComponentMainViewModel();		
		cust.setName(custName.trim());
		cust.setAddressLine1(address1.trim());
		cust.setAddressLine2(address2.trim());
		cust.setMobileNo(CustMobileNo);
		cust.setCode(masterCode);
		cust.setPanNo(panNo);
		cust.setArea(area);
		cust.setCity(city);
		cust.setPhoneNo(phoneNo);
		cust.setPinCode(pinCode);
		
		orderVm.setCustomerDetailsViewModel(cust);
		orderVm.setSchemeDataViewModel(SchemeData);
		orderVm.setOrderDataViewModel(orderDataVm);
		//orderVm.setDate(docDate);
		orderVm.setOwnCode(ownCode);
		orderVm.setCustomerCode(personCode);
		//orderVm.setMaturityDate(dueDate);
		orderVm.setVoucherNo(series+"-"+docNo);
		orderVm.setBranchCode(branchCode);
		CustomerSchemeOutputVm customerVm = new CustomerSchemeOutputVm();	
		customerVm.setResult(orderVm);
		
		SchemeOperationVm vm = new SchemeOperationVm();
		vm.setData(customerVm);
		return vm;
	}
	
	public void getOrderDetails(int orderNo) throws ClassNotFoundException, SQLException
	{
		   DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
           Connection con = databaseConnectionService.databaseConnectionMethod();

	       //Class.forName("com.mysql.jdbc.Driver");	   			     			 
		   JSONObject obj=new JSONObject(orderNo);
		   //System.out.println("value"+obj.get("orderNo").toString());
		   seriesDocNoList.addAll(Arrays.asList(obj.get("orderNo").toString().split("-")));
		   //System.out.println("1 .. "+seriesDocNoList.get(0));
		  // System.out.println("2 ... "+seriesDocNoList.get(1));
		   series =  seriesDocNoList.get(0);
		   docNo  =  seriesDocNoList.get(1);
		   docNo  =  docNo.trim();
		   int doc = Integer.parseInt(docNo);	
		   //System.out.println("series > "+series+"  docNo > "+docNo);
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/PngSons_15March","AcmeInfi","ProteasLankans");	
		   java.sql.Statement stmt1=con.createStatement();
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE COMPCODE=1 AND DOCUMENTTYPECODE=6 AND DOCUMENTSUBTYPE = 'B' AND DOCNO="+doc+" AND SERIES ='"+series+"'");
		   try
		   {
	    	 while(rs.next())
	    	 {
	    		  series             =  rs.getString("series");
	    		  documentNo         =  rs.getInt("docNo");
	    		  docMasterCode      =  rs.getInt("documentMasterCode"); 
	    		  ownCode            =  rs.getInt("ownCode"); 
	    		  docDate 	         =  rs.getInt("docDate");
	    		  personCode  	     =  rs.getInt("personCode"); 
	    		  refDocOwnCode      =  rs.getInt("refDocOwnCode"); 
	    		  advanceAmount      =  rs.getInt("advanceAmount");
	    		  adjustmentMethod   =  rs.getInt("adjustmentMethod");
	    		  documentTypeCode   =  rs.getInt("documentTypeCode");
	    		  documentMasterCode =  rs.getInt("documentMasterCode");
	    		  dueDate  		     =  rs.getInt("dueDate");
	    		  locationCode1 	 =  rs.getInt("locationCode1");
	    		  locationCode2 	 =  rs.getInt("locationCode2");
	    	 }		
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
	}
	
	public void getCustomerDetails(int personCode) throws ClassNotFoundException, SQLException
	{
   		 DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
         Connection con = databaseConnectionService.databaseConnectionMethod();

	     //java.sql.Connection con1= null;
		 //Class.forName("com.mysql.jdbc.Driver");
		 //con1 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/PngSons_15March","AcmeInfi","ProteasLankans");		 
		 java.sql.Statement stmt2=con.createStatement();
		 ResultSet rs2;    	    
		 rs2=stmt2.executeQuery("SELECT a.fieldValue,b.fieldvalue ,a.mastercode,c.fieldvalue,d.fieldvalue,e.fieldvalue,g.fieldvalue,h.fieldvalue,j.fieldvalue,K.fieldvalue FROM PrimeMasterDetails a JOIN PrimeMasterDetails b ON a.CompCode=b.CompCode AND a.masterType=b.masterType AND b.fieldno=10 AND  a.mastercode=b.mastercode JOIN PrimeMasterDetails c ON a.CompCode=c.CompCode AND a.masterType=c.masterType AND c.fieldno=40 AND a.mastercode=c.mastercode JOIN PrimeMasterDetails d ON a.CompCode=d.CompCode AND a.masterType=d.masterType AND d.fieldno=50 AND a.mastercode=d.mastercode JOIN PrimeMasterDetails e ON a.CompCode=e.CompCode AND a.masterType=e.masterType AND e.fieldno=200 AND a.mastercode=e.mastercode JOIN PrimeMasterDetails j ON a.CompCode=j.CompCode AND a.masterType=j.masterType AND j.fieldno=80 AND a.mastercode=j.mastercode JOIN PrimeMasterDetails K ON a.CompCode=K.CompCode AND a.masterType=K.masterType AND K.fieldno=70 AND a.mastercode=K.mastercode JOIN PrimeMasterDetails i ON a.CompCode=i.CompCode AND a.masterType=i.masterType AND i.fieldno=60 AND a.mastercode=i.mastercode LEFT JOIN SecondaryMasterDetails g ON i.FieldValue = g.MasterCode AND g.Mastertype = 19  AND g.FieldNo = 10 LEFT JOIN SecondaryMasterDetails h ON i.FieldValue = h.MasterCode AND h.Mastertype = 16  AND h.FieldNo = 10 where a.mastercode="+personCode+" AND a.mastertype=7 AND a.compcode=1 AND a.fieldno=30 ");
		 try
		 {
		   while(rs2.next())
      	    {
			   custName      =  rs2.getString("b.FieldValue");
      		 	area         =  rs2.getString("g.FieldValue");
      		 	city         =  rs2.getString("h.FieldValue");
      		 	CustMobileNo =  rs2.getLong("a.FieldValue");
      		 	address1     =  rs2.getString("c.FieldValue");
      		 	address2     =  rs2.getString("d.FieldValue");
      		 	panNo        =  rs2.getString("e.FieldValue");
      		 	masterCode   =  rs2.getInt("a.mastercode");
      		 	phoneNo      =  rs2.getString("j.fieldvalue");
      		 	pinCode      =  rs2.getString("K.fieldvalue");          		
      	    }
		 }
		 catch(Exception e)
		 {
		  	 System.out.println(e);
		 }
	}
	
	public void getBranchCode(int ownCode) throws ClassNotFoundException, SQLException 
	{		
		DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
        Connection con = databaseConnectionService.databaseConnectionMethod();

		   //Class.forName("com.mysql.jdbc.Driver");
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/PngSons_15March","AcmeInfi","ProteasLankans");	
		   java.sql.Statement stmt1=con.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT b.FieldValue FROM DocumentMainTable a JOIN SecondaryMasterDetails b ON a.compCode=b.CompCode AND b.mastertype=10 AND b.mastercode=a.locationcode2 AND b.fieldno=30 WHERE a.COMPCODE=1 AND a.OwnCode="+ownCode+"");
		   try
		   {
			while(rs.next())
         	 {
				branchCode      =  rs.getInt("b.FieldValue");
         	 }
		   }
		   catch(Exception e)
		   {
		    	 System.out.println(e);
		   }
	}	
	
}
