/*-
 *  File    :   MyController.java
 *  Version	:   1.0
 *	Date    :   Jan 6, 2018
 *  Author  :   Raviraj S Mahamuni
 *
 * Copyright (c) 1993-2015 Acme Infovision Private Limited, Satara. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Acme Infovision
 * Private Limited. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Acme.
 */


package com.raviraj.webapp;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.raviraj.sample.model.Person;
import com.raviraj.sample.model.PersonId;
import com.raviraj.sample.service.PersonService;


/**
 * @author Raviraj S Mahamuni
 * @date Jan 6, 2018
 * @since 1.0
 */

@Controller
public class MyController {

    @Autowired
    private PersonService personServcice;

    // @ResponseBody
    // @RequestMapping(name = "/hello")
    // public String test1() {
    //
    // return "Hello World";
    // }

    @RequestMapping(value = "/person/{id}")
    public Person getPerson(@PathVariable Integer id) {

        PersonId personId = new PersonId();
        personId.setCompCode(1);
        personId.setTenantCode(1);
        personId.setOwnCode(id);
        return personServcice.getPerson(personId);
    }

}
