package com.acme.cashmachine;

public interface validationFunstionsService 
{
	public  boolean validateJavaDate(String strDate);

}
