package com.acme.cashmachine;
import com.acme.cashmachine.model.CustomerSchemeOutputVm;
import com.acme.cashmachine.model.DatabaseConnectionService;
import com.acme.cashmachine.model.GetDataFromDBService;
import com.acme.cashmachine.model.GetDocNo;
import com.acme.cashmachine.model.InstallmentsVm;
import com.acme.cashmachine.model.OrderVm;
import com.acme.cashmachine.model.PaymentDetailsVm;
import com.acme.cashmachine.model.SchemeDetailVm;
import com.acme.cashmachine.model.SchemeValidatorVm;
import com.acme.cashmachine.model.UpdateTableData;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class addInstallment
{	
	
	
	private GetDataFromDBService getDataFromDBService;
	private DatabaseConnectionService databaseConnectionService;	
	private validationFunstionsService validationFunstionsService;
	@Autowired
	public addInstallment(GetDataFromDBService getDataFromDBService,
			DatabaseConnectionService databaseConnectionService,
			validationFunstionsService validationFunstionsService) 
	{
		this.getDataFromDBService =getDataFromDBService;
		this.databaseConnectionService =databaseConnectionService;
		this.validationFunstionsService  = validationFunstionsService;
	}	
	
    int ownCode;
	int count=0;
	
	//String series,docNo,memoType,seriesFromAutoNoTable,defaultSeries;
	//int date,saleRate,documentNo,getOrderDetailsFlag=0,docMasterCode;
	InstallmentsVm vm=new InstallmentsVm();
	SchemeDetailVm schemeVm = new SchemeDetailVm();
	List<String> seriesDocNoList = new ArrayList<>();	
	
	GetDocNo getDocno=new GetDocNo();

	@RequestMapping(value = "/scm/v1/scheme/3", method = RequestMethod.POST)
	public SchemeValidatorVm addInstallmentMethod(
			@RequestBody InstallmentsVm vm) 
	{	
		  Connection con11=null;
		  OrderVm orderVm = new OrderVm();
		  SchemeValidatorVm vmCust = new SchemeValidatorVm();		
		  PaymentDetailsVm paymentDetailsVm = new PaymentDetailsVm();
		  String orderNo      = vm.getOrderNo();	 
		  //System.out.println("orderNo !!! "+orderNo);		
		  
		   int date2        = getDataFromDBService.todaysGetDateTime();
		   //System.out.println("todaysGetDateTime >> "+date2);
		   String date3    = getDataFromDBService.dateConversionforClarion(vm.getDate());
		   int date4        = getDataFromDBService.getDateTime(date3);
		   //Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		   //System.out.println("dae>> "+date1);
		   int saleRate    = getDataFromDBService.getTodaysRate(date4);
		   //System.out.println("saleRate >> "+saleRate);
		   if(saleRate == 0)
			 {
				vmCust.setErrorCode(1001);
				vmCust.setErrorMsg("Rates are not set against "+vm.getDate()+" date .");
				vmCust.setResult(null);
				return vmCust;
			 }		
		   
		 if(orderNo == null || orderNo.isEmpty())
		 {
			vmCust.setErrorCode(1001);
			vmCust.setErrorMsg("Please Provide Order No");
			vmCust.setResult(null);
			return vmCust;
		 }		 		 		
		
		 try 
		 {	
			   //Connection con = databaseConnectionService.databaseConnectionMethod();
			   Class.forName("com.mysql.jdbc.Driver");		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

			 if(con11==null)
			 {
				vmCust.setErrorCode(1001);
				vmCust.setErrorMsg("Cannot Connect to Database");
				vmCust.setResult(null);
				return vmCust;
			 }
			//GetDataFromDBServiceImpl getDataFromDBService=new GetDataFromDBServiceImpl();
			Map<String, Object> resultMap = getDataFromDBService.getOrderDetails(orderNo);
			if(resultMap==null || resultMap.isEmpty()){
				vmCust.setErrorCode(1001);
				vmCust.setErrorMsg(orderNo+ " Order Not Found");
				vmCust.setResult(null);
				return vmCust;
			}
			orderVm.setOwnCode(Integer.valueOf(resultMap.get("ownCode").toString()));
			orderVm.setDocDate((String)resultMap.get("docDate"));
			orderVm.setAdvanceAmount(Integer.valueOf(resultMap.get("AdvanceAmount").toString()));
			orderVm.setSchemeCode(Integer.valueOf(resultMap.get("schemeCode").toString()));
			orderVm.setInstallmentNo(Integer.valueOf(resultMap.get("installmentNo").toString()));
			orderVm.setDocumentNo(Integer.valueOf(resultMap.get("documentNo").toString()));
			orderVm.setRefDocOwnCode(Integer.valueOf(resultMap.get("setRefDocOwnCode").toString()));	
			orderVm.setLocCode2(Integer.valueOf(resultMap.get("LocationCode2").toString()));	
			orderVm.setPersonCode(Integer.valueOf(resultMap.get("personCode").toString()));
			orderVm.setMemoType((String) resultMap.get("memoType"));
			orderVm.setDocumentSeries((String) resultMap.get("series"));
			orderVm.setDocumentMasterCode(Integer.valueOf(resultMap.get("documentMasterCode").toString()));
			//System.out.println("Abc >> "+Integer.valueOf(resultMap.get("masterCodeForNewDmnRecord").toString()));
			orderVm.setMasterCodeForNewDmnRecord(Integer.valueOf(resultMap.get("masterCodeForNewDmnRecord").toString()));
			
			
				 if(orderVm.getPersonCode() != vm.getCustomerCode())
				 {
					vmCust.setErrorCode(1001);
					vmCust.setErrorMsg("Provided Customer Code is not valid");
					vmCust.setResult(null);
					return vmCust;
				 }
				 
				 if(orderVm.getSchemeCode() != vm.getSchemeCode())
				 {
					vmCust.setErrorCode(1001);
					vmCust.setErrorMsg("Provided Scheme Code is not valid");
					vmCust.setResult(null);
					return vmCust;
				 }				 						 
				 
				 List<PaymentDetailsVm> paymentVm = vm.getPaymentDetails();
				 for (PaymentDetailsVm paymentDetailsVm2 : paymentVm) {
					 paymentDetailsVm2.getOriginalAmt();
					 BigDecimal deci=  paymentDetailsVm2.getOriginalAmt();
					 double value = deci.doubleValue();
					 
					 if(vm.getAmount() == 0)
					 {
						vmCust.setErrorCode(1001);
						vmCust.setErrorMsg("Invalid amount");
						vmCust.setResult(null);
						return vmCust;
					 }	
					 
					 if( value == 0)
					 {
						vmCust.setErrorCode(1001);
						vmCust.setErrorMsg("Invalid original amount");
						vmCust.setResult(null);
						return vmCust;
					 }						
					 
					 /*if(vm.getAmount() != value)
					 {
						vmCust.setErrorCode(1001);
						vmCust.setErrorMsg("Amount and orginal amounts are not matching");
						vmCust.setResult(null);
						return vmCust;
					 }*/	
				  }
				 
				 int maturityDate = getDataFromDBService.getMaturitydate(orderVm.getOwnCode());

				 String date = getDataFromDBService.getDdMmYyDate(maturityDate);			 
				 DateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
			     Date dueDate = df1.parse(date);			     

			     Date installmentDate = df1.parse(vm.getDate());
			     String orderDate = getDataFromDBService.getDdMmYyDate(Integer.parseInt(orderVm.getDocDate()));			     
			     Date OrderDate= df1.parse(orderDate);			     			    			    			    
			     
			     if (!vm.getDate().matches("([0-9]{2})/([0-9]{2})/([0-9]{4})"))
			     {
			    	    vmCust.setErrorCode(1001);
						vmCust.setErrorMsg("Invalid date format. Date should be in dd/mm/yyyy format.");
						vmCust.setResult(null);
						return vmCust; 
			     }
			     
			     if(installmentDate.compareTo(OrderDate) < 0)
				 {
					vmCust.setErrorCode(1001);
					vmCust.setErrorMsg("Installment date should be greater than order date");
					vmCust.setResult(null);
					return vmCust;
				 }
			     
				 if(installmentDate.compareTo(dueDate) > 0)
				 {
					vmCust.setErrorCode(1001);
					vmCust.setErrorMsg("Installment date is greater than maturity date");
					vmCust.setResult(null);
					return vmCust;
				 }
				
				 Map<String, Object> allowVariableInstallmntAmountMapResult= getDataFromDBService.allowVariableInstallmntAmount(orderVm.getSchemeCode());
				 String alloVariableInstallmntAmt = (String) allowVariableInstallmntAmountMapResult.get("variableInstallmnt");
				 int amountMultipleOf = Integer.valueOf(allowVariableInstallmntAmountMapResult.get("amountMultipleOf").toString());
				 int minAmount = Integer.valueOf(allowVariableInstallmntAmountMapResult.get("minAmount").toString());
				 //System.out.println("alloVariableInstallmntAmt >> "+alloVariableInstallmntAmt+"  amountMultipleOf >> "+amountMultipleOf+" minAmount >> "+minAmount);
				 
				 int noOfMonths = getDataFromDBService.getNoOfMonths(orderVm.getSchemeCode());
				 int noOfInstallment = getDataFromDBService.installmentNumber(orderVm.getOwnCode(),orderVm.getAdvanceAmount());
				 //System.out.println("alloVariableInstallmntAmt >> "+alloVariableInstallmntAmt);
				 if (alloVariableInstallmntAmt.equals("No"))
				 {					 
					 noOfInstallment +=  vm.getNoOfInstallment();
					 
					 if(vm.getAmount() % orderVm.getAdvanceAmount() != 0)
					 {
						vmCust.setErrorCode(1001);
						vmCust.setErrorMsg("Provided Amount is not valid");
						vmCust.setResult(null);
						return vmCust;
					 }
					 
					 if((noOfMonths * orderVm.getAdvanceAmount()) < (noOfInstallment * orderVm.getAdvanceAmount()))
					 {
						 if((noOfMonths * orderVm.getAdvanceAmount()) == (noOfInstallment * orderVm.getAdvanceAmount()))
						 {
							    vmCust.setErrorCode(1001);
								vmCust.setErrorMsg(noOfMonths+" installments are completed. You cannot add installments.");
								vmCust.setResult(null);
								return vmCust;
						 }
						 else
						 {
							    vmCust.setErrorCode(1001);
								vmCust.setErrorMsg("You cannot add installments.");
								vmCust.setResult(null);
								return vmCust;
						 }
						
					 }
				 }
				 
				 else
				 {		
					 
					 if(vm.getAmount() < minAmount )
					 {
						    vmCust.setErrorCode(1001);
							vmCust.setErrorMsg("Minimum amount should be "+minAmount);
							vmCust.setResult(null);
							return vmCust;
					 }
					 
					 if(vm.getAmount() % amountMultipleOf != 0 )
					 {
						    vmCust.setErrorCode(1001);
							vmCust.setErrorMsg("Amount should be multiple of "+amountMultipleOf);
							vmCust.setResult(null);
							return vmCust;
					 }
					 int installmentCount = getDataFromDBService.getInstallmentCount(orderVm.getOwnCode());
					 //System.out.println("installmentCount >> "+installmentCount);
					 if(vm.getNoOfInstallment() != 1)
					 {
						    vmCust.setErrorCode(1001);
							vmCust.setErrorMsg("Installment number should be one(1)");
							vmCust.setResult(null);
							return vmCust;
					 }
/*					 if((installmentCount) >= noOfMonths)
					 {
						    vmCust.setErrorCode(1001);
							vmCust.setErrorMsg(noOfMonths+" Installments are completed. You cannot add installment.");
							vmCust.setResult(null);
							return vmCust;
					 }
*/				 }
				 
				 Map<String, Object> result	= installmentAddMethod(vm.getAmount(),vm.getCustomerCode(),orderNo,orderVm,vm,vm.getNoOfInstallment(),vm.getDate());
				 int ownCd= Integer.valueOf(result.get("ownCode").toString());
				 String installmentNo = (String) result.get("InstallmentNo");
				 //System.out.println("ownCd >> "+ownCd+"  installmentNo >>  "+installmentNo);
			if(ownCd == 0){
				
				vmCust.setErrorCode(1001);
				vmCust.setErrorMsg("Error While Adding Installment");
				vmCust.setResult(null);
			}else{
				Map<String,Object> map = new LinkedHashMap<>();
				
				//System.out.println("orderVm.getPersonCode() >> "+orderVm.getPersonCode()+"  vm.getCustomerCode() >> "+vm.getCustomerCode());
				vmCust.setErrorCode(0);
				vmCust.setErrorMsg("Installment Added Successfully");
				map.put("installmentNo", installmentNo);
				map.put("ownCode", ownCd);
				vmCust.setResult(map);
			}
				
				return vmCust;				
	      } 
		  catch (Exception e) 
		    {			  
				if(orderVm.getOwnCode() == 0)
				 {
					vmCust.setErrorCode(1001);
					vmCust.setErrorMsg("Please, Provide valid Order No");
					vmCust.setResult(null);
					return vmCust;
				 }		
			  
			    vmCust.setErrorCode(1001);
				vmCust.setErrorMsg("Error While Adding Installment :: "+e.getMessage());
				vmCust.setResult(null);
				return vmCust;						    
			}			   
		
     	//return vmCust;
	}

	private   Map<String, Object> installmentAddMethod(double amount,int customerCode,String orderNo, OrderVm orderVm,InstallmentsVm vm,int noOfInstallment,String date1) throws Exception
	{
		   Map<String, Object> installmentResult = new LinkedHashMap<String, Object>();
		   //GetDataFromDBServiceImpl getDataFromDBServiceImpl =new GetDataFromDBServiceImpl();
		   
		   
		   String date2    = getDataFromDBService.dateConversionforClarion(date1);
		   int date        = getDataFromDBService.getDateTime(date2);
		   //System.out.println("dateConversionforClarion >> "+date2+"    getDateTime > "+date);
		   //Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		   //System.out.println("dae>> "+date1);
		   int saleRate    = getDataFromDBService.getTodaysRate(date);
		   int getOwnCodeForAccTable = getDataFromDBService.getOwnCodeForAccountsTable();
		   int ownCode     = getDataFromDBService.getOwnCodeForDMN();
		   long currentTime = getDataFromDBService.getClarionTime();
		   //System.out.println("currentTime >> "+currentTime);
		   //System.out.println(" ownCode >> "+ownCode);
		   int DocNoForDMN = orderVm.getDocumentNo();//getDataFromDBService.getDocNo(orderVm.getDocumentMasterCode());
		   String series   = orderVm.getDocumentSeries();
		   int masterCodeForNewDmnRecord = orderVm.getMasterCodeForNewDmnRecord();
		   int installmentNo = orderVm.getInstallmentNo();
		   installmentNo += 1;
		   int userCode = getDataFromDBService.getUser();
		   Connection con11=null;
		try
		 {	
		   Class.forName("com.mysql.jdbc.Driver");		       
		   con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");			
		   String seriesForInsert = getDocno.getSeriesFromAutoNoTable(); 
		   java.sql.Statement stmt1=con11.createStatement();		
		   java.sql.Statement stmt2=con11.createStatement();
		   java.sql.Statement stmt3=con11.createStatement();	
		   java.sql.Statement stmt4=con11.createStatement();	
		   java.sql.Statement stmt5=con11.createStatement();	
		   java.sql.Statement stmt6=con11.createStatement();
		   java.sql.Statement stmt7=con11.createStatement();	
		   int count1=0,count2=0,count3=0;
		   		
			/*if (orderVm.getMemoType().equals("A"))
			{         																														//"+getDocno.getSeriesFromAutoNoTable()+"
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'8','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'A','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'0','0','0','0','0','0.00','0.000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0')");
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'8','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'A','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'23','0','','0','0','0','0.000','0.00','0.00','0.00','N','0','','0','0.000','0.00','0','0','0','0','','','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','','0.00','0','0','0','0','','0','0','','0','0','','0','0','','0','0','0.000','0.000','0.000','0','0','0','Applicable','','1','1','5357','0','1','1.50','0.00','1.50','0.00','0.00','0.00','0.00','0.00','0.00','N','N','0','0.00','0.00','0','0','','0','0','0','0','11213','79385','79385','1','1.00','1')");
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1','444444','3597','6','B','JNBM','2358','','0','79385','79385','','','11213','','0','79719','11213','1','0','1','89','11','0.00','0.00','0.00','0.00','1000.00','79385','3832201','3423','1','1','1','0.0000','0.0000','0.0000','0.0000','0.00','1.00','0.0000','0','0','0','144','Y','1000.00','0.00','19','','0','6','0','0','0','1029','23','0','','0','0','0','0.000','0.00','0.00','0.00','N','0','','0','0.000','0.00','0','0','0','0','','','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','','0.00','0','0','0','0','','0','0','','0','0','','0','0','','0','0','0.000','0.000','0.000','0','0','0','Applicable','','1','1','5357','0','1','1.50','0.00','1.50','0.00','0.00','0.00','0.00','0.00','0.00','N','N','0','0.00','0.00','0','0','','0','0','0','0','11213','79385','79385','1','1.00','1')");
				count1=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'8','B','JNBM',"+DocNoForDMN+",'0','0',"+date+","+date+",'"+orderNo+"','0',"+orderVm.getPersonCode()+",'0','0','0',"+orderVm.getLocCode2()+","+orderVm.getPersonCode()+","+orderVm.getRefDocOwnCode()+",'0','0','0','0.00','0.00','0.00','0.00','"+amount+"',"+date+",'0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','66666','0','0','0',"+saleRate+",'0','0','0','0','0','0','0.000','0.00','0.00','0.00','0','0','0','0','0.000','0.00','0','0','0','0','0','0','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','0','0.00','0','0','0','0','','0','0','0','0','0','0','0','0','0','0','0','0.000','0.000','0.000','0','0','0','0','0','1','2','0','0','0','0','0.00','0','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0','0','0','0','0','0')");
				count2=stmt2.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				getOwnCodeForAccTable +=1 ;
				count3=stmt3.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				System.out.println("1...");
			}
			else if(orderVm.getMemoType().equals("M"))
			{
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'7','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'M','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'0','0','0','0','0','0.00','0.000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0')");
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'7','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'M','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'23','0','','0','0','0','0.000','0.00','0.00','0.00','N','0','','0','0.000','0.00','0','0','0','0','','','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','','0.00','0','0','0','0','','0','0','','0','0','','0','0','','0','0','0.000','0.000','0.000','0','0','0','Applicable','','1','1','5357','0','1','1.50','0.00','1.50','0.00','0.00','0.00','0.00','0.00','0.00','N','N','0','0.00','0.00','0','0','','0','0','0','0','11213','79385','79385','1','1.00','1')");
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1','444444','3597','6','B','JNBM','2358','','0','79385','79385','','','11213','','0','79719','11213','1','0','1','89','11','0.00','0.00','0.00','0.00','1000.00','79385','3832201','3423','1','1','1','0.0000','0.0000','0.0000','0.0000','0.00','1.00','0.0000','0','0','0','144','Y','1000.00','0.00','19','','0','6','0','0','0','1029','23','0','','0','0','0','0.000','0.00','0.00','0.00','N','0','','0','0.000','0.00','0','0','0','0','','','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','','0.00','0','0','0','0','','0','0','','0','0','','0','0','','0','0','0.000','0.000','0.000','0','0','0','Applicable','','1','1','5357','0','1','1.50','0.00','1.50','0.00','0.00','0.00','0.00','0.00','0.00','N','N','0','0.00','0.00','0','0','','0','0','0','0','11213','79385','79385','1','1.00','1')");
				count1=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'7','B','JNBM',"+DocNoForDMN+",'0','0',"+date+","+date+",'"+orderNo+"','0',"+orderVm.getPersonCode()+",'0','0','0',"+orderVm.getLocCode2()+","+orderVm.getPersonCode()+","+orderVm.getRefDocOwnCode()+",'0','0','0','0.00','0.00','0.00','0.00','"+amount+"',"+date+",'0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','66666','0','0','0',"+saleRate+",'0','0','0','0','0','0','0.000','0.00','0.00','0.00','0','0','0','0','0.000','0.00','0','0','0','0','0','0','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','0','0.00','0','0','0','0','','0','0','0','0','0','0','0','0','0','0','0','0.000','0.000','0.000','0','0','0','0','0','1','2','0','0','0','0','0.00','0','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0','0','0','0','0','0')");
				count2=stmt2.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				getOwnCodeForAccTable +=1 ;
				count3=stmt3.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				System.out.println("2...");
			}
			else
			{																																	    //"+getDocno.getDocumentNo()+1+"
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'8','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'0','0','0','0','0','0.00','0.000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0')");
				//count=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+orderVm.getDocumentMasterCode()+",'8','B','"+defaultSeries+"',"+documentNo+",'0','0',"+date+","+date+",'0','0',"+orderVm.getPersonCode()+",'','0','0',"+orderVm.getPersonCode()+","+orderVm.getLocCode2()+","+orderVm.getRefDocOwnCode()+",'3','0','0','0.00','0.00','0.00','0.00','"+amount+"','0','0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','0','0','0','0',"+saleRate+",'23','0','','0','0','0','0.000','0.00','0.00','0.00','N','0','','0','0.000','0.00','0','0','0','0','','','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','','0.00','0','0','0','0','','0','0','','0','0','','0','0','','0','0','0.000','0.000','0.000','0','0','0','Applicable','','1','1','5357','0','1','1.50','0.00','1.50','0.00','0.00','0.00','0.00','0.00','0.00','N','N','0','0.00','0.00','0','0','','0','0','0','0','11213','79385','79385','1','1.00','1')");
				count1=stmt1.executeUpdate("INSERT INTO DocumentMainTable  VALUES('1',"+ownCode+","+masterCodeForNewDmnRecord+",'8','B','"+series+"',"+DocNoForDMN+",'0','0',"+date+","+date+",'"+orderNo+"','0',"+orderVm.getPersonCode()+",'0','0','0',"+orderVm.getLocCode2()+","+orderVm.getPersonCode()+","+orderVm.getRefDocOwnCode()+",'0','0','0','0.00','0.00','0.00','0.00','"+amount+"',"+date+",'0','0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount+",'0.0000','0','0','0','0','0','0','0.00','0','0','0','66666','0','0','0',"+saleRate+",'0','0','0','0','0','0','0.000','0.00','0.00','0.00','0','0','0','0','0.000','0.00','0','0','0','0','0','0','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','0','0.00','0','0','0','0','','0','0','0','0','0','0','0','0','0','0','0','0.000','0.000','0.000','0','0','0','0','0','1','2','0','0','0','0','0.00','0','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0','0','0','0','0','0')");
				count2=stmt1.executeUpdate("INSERT INTO AccPaymentDetails VALUES('1',"+getOwnCodeForAccTable+",'6',"+orderVm.getDocumentMasterCode()+","+ownCode+",'158398','1','1',"+amount+",'0','0','','','0.00','0.00','0.00','0','0','','0','0','0','0.0000','0.0000','0','0','2000.00','0','0','10635','YADAV ANIKET','0','0','0','0','0','1','N','0','0','0','0','0','0.000')");
				//count2=stmt2.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				//getOwnCodeForAccTable +=1 ;
				//count3=stmt3.executeUpdate("INSERT INTO  AccountsTable  VALUES('1','"+getOwnCodeForAccTable+"','8',"+orderVm.getRefDocOwnCode()+",'35616','79382','1','1','0','1','0','1','8','0','5000.00','79382','0.00','0','0','1','28707','0','','','may','JBH-1616','','','','0','SAVING SCHEME A/C','1','0','0.00','0','0','0','0','0','0','0','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','0','','0','0.000','0','0.000','0.000','0.000','0.000','0')");
				System.out.println("3...");
			}				*/
		   
       	   count1=stmt1.executeUpdate("INSERT IGNORE INTO DocumentMainTable  VALUES('1',"+ownCode+","+masterCodeForNewDmnRecord+",'8','B','"+series+"',"+DocNoForDMN+",'0','0',"+date+","+date+",'"+orderNo+"','0',"+orderVm.getPersonCode()+",'0','0','0',"+orderVm.getLocCode2()+","+orderVm.getPersonCode()+","+orderVm.getRefDocOwnCode()+","+orderVm.getSchemeCode()+",'0',"+vm.getNoOfInstallment()+",'0.00','0.00','0.00','0.00','"+amount*noOfInstallment+"',"+date+","+currentTime+",'0','0','1','0','0.0000','0.0000','0.0000','0.0000','0.00',"+amount*noOfInstallment+",'0.0000','0','0','0','0','Y',"+amount*noOfInstallment+",'0.00',"+userCode+",'0','0','8','0','0','0',"+saleRate+",'0','0','0','0','0','0','0.000','0.00','0.00','0.00','0','0','0','0','0.000','0.00','0','0','0','0','0','0','0','0','0','0.00','0.00','0','0','0.00','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.00','0.00','0.00','0','0','0','0','0','0','0.00','0','0','0','0','','0','0','0','0','0','0','0','0','0','0','0','0.000','0.000','0.000','0','0','0','Applicable','0','1','1','0','0','0','0','0.00','0','0.00','0.00','0.00','0.00','0.00','0.00','0','0','0','0.00','0.00','0','0','0','0','0','0','0')");
 		   count2=stmt2.executeUpdate("INSERT IGNORE INTO AccPaymentDetails VALUES('1',"+getOwnCodeForAccTable+",'6',"+orderVm.getDocumentMasterCode()+","+ownCode+",'158398','1','1',"+amount*noOfInstallment+",'0','0','','','0.00','0.00','0.00','0','0','','0','0','0','0.0000','0.0000','0','0','2000.00','0','0','10635','YADAV ANIKET','0','0','0','0','0','1','N','0','0','0','0','0','0.000')");
   		   //count3=stmt2.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3040','','0','0','N','0','0','0')");
     	   count2=stmt3.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3060',"+amount*noOfInstallment+",'0','0','N','0','0','0')");
     	   count2=stmt4.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3210',"+installmentNo+",'0','0','N','0','0','0')");
     	   count2=stmt5.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3220',"+installmentNo+",'0','0','N','0','0','0')");
     	   //count2=stmt2.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3070','','0','0','N','0','0','0')");
     	   //count2=stmt2.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3080','','0','0','N','0','0','0')");
     	   count2=stmt6.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3170',"+amount*noOfInstallment+",'0','0','N','0','0','0')");
     	   count2=stmt7.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3190',"+amount*noOfInstallment+",'0','0','N','0','0','0')");
     	   // count2=stmt2.executeUpdate("INSERT IGNORE INTO DocSub  VALUES('1','1','13',"+ownCode+",'3200','','0','0','N','0','0','0')");
		   
		   // System.out.println("Executed 2");
		   if (count1 == 0 && count2 == 0)
			   {				 					 
			   		count1 = 0; 
			   		installmentResult.put("InstallmentNo", "");
			   		installmentResult.put("ownCode", 0);
			   		return installmentResult;						 
		       }
		   else
		       {
			       UpdateTableData updateService=new UpdateTableData();
			       updateService.updateAutoNoTable(count1,ownCode,"A");
			       updateService.updateAutoNoTable(count1,getOwnCodeForAccTable,"DPay");			       
			       updateService.updateAutoNoTableForDoc(DocNoForDMN,masterCodeForNewDmnRecord);
		    	   //updateAutoNoTable();	
			       //updateService.updateAutoNoTableForDoc(DocNoForDMN, orderVm.getDocumentMasterCode());
		    	   //updateAutoNoTableForDoc();
			        installmentResult.put("InstallmentNo", series+"-"+DocNoForDMN);
			   		installmentResult.put("ownCode", ownCode);
		    	   return installmentResult;
		       }
		    }
		 
		   catch(Exception e)
		   {
		    	throw new Exception("Error while inserting installment Record : "+e.getMessage());
		   }
			finally
		   {
			   con11.close();	
		   }				
	}

}
