package com.acme.cashmachine;
import com.acme.cashmachine.passOrdeeNo;
import com.acme.cashmachine.model.CustomerDetailsViewModel;
import com.acme.cashmachine.model.CustomerSchemeOutputVm;
import com.acme.cashmachine.model.OrderComponentMainViewModel;
import com.acme.cashmachine.model.OrderDataViewModel;
import com.acme.cashmachine.model.OrderItemDetailsViewModel;
import com.acme.cashmachine.model.SchemeDataViewModel;
import com.acme.cashmachine.model.SchemeOperationVm;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

@RestController
public class GetOrderDetails 
{
	@RequestMapping(value = "/scm/v1/scheme/5", method = RequestMethod.POST)
	public String orderDetails(
			@RequestBody  int customerCode) 
	{	
		return "Pavan";
	}

}
