package com.acme.cashmachine.model;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetDataFromDBServiceImpl implements GetDataFromDBService
{
	private DatabaseConnectionService databaseConnectionService;
	@Autowired
	public GetDataFromDBServiceImpl(DatabaseConnectionService databaseConnectionService) {
	this.databaseConnectionService =databaseConnectionService;
	}
	int date=0;
	//DatabaseConnectionService databaseConnectionService =new DatabaseConnectionService();
	//Connection con = databaseConnectionService.databaseConnectionMethod();
	//DataInsertService dataInsertService=new DataInsertService();
	ReadDataFromWebConfig readDataFromWebConfig = new ReadDataFromWebConfig();
	
	@Override
	public Map<String, Object> getOrderDetails(String orderNo) throws Exception 
	{	 
		//DatabaseConnectionService databaseConnectionService=new DatabaseConnectionService();
		//Connection DbConnection = databaseConnectionService.databaseConnectionMethod();
		//System.out.println("con >> "+con);
		int count = 0;
		int documentNo = 0,DocumentMasterCodeForNextTransaction4;
		String defaultSeries = null;
		OrderVm orderVm = new OrderVm();
		Map<String, Object> orderDetailsResult = new LinkedHashMap<String, Object>();
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{		                
		       //Class.forName("com.mysql.jdbc.Driver");		       
			   JSONObject obj=new JSONObject("{ orderNo : "+orderNo+"}");
			   //System.out.println("value"+obj.get("orderNo").toString());			   
			   String series =  orderNo.replaceAll("[^a-z || A-Z]", "").trim();//numbers2.trim();//seriesDocNoList.get(0);			   
			   int doc = Integer.parseInt(orderNo.replaceAll("[^0-9]", "").trim());	
			   //System.out.println("series > "+series+"  docNo > "+doc);
			   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			   Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

			   java.sql.Statement stmt1=con11.createStatement();			   
			   ResultSet rs;    	    
			   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE COMPCODE=1 AND DOCUMENTTYPECODE=6 AND DOCUMENTSUBTYPE = 'B' AND DOCNO="+doc+" AND SERIES ='"+series+"'");
		      
		   			while(rs.next())
		   				{
		   					count = 1;
		   					orderVm.setOwnCode(rs.getInt("owncode"));
		   					orderVm.setDocumentNo(rs.getInt("docNo"));
		   					orderVm.setDocDate(String.valueOf(rs.getInt("docDate")));
		   					orderVm.setSchemeCode(rs.getInt("adjustmentMethod"));
		   					orderVm.setAdvanceAmount(rs.getInt("AdvanceAmount"));
		   					//orderVm.setDbConnection(DbConnection);
		   					orderVm.setRefDocOwnCode(rs.getInt("OwnCode"));		   					
		   					orderVm.setLocCode2(rs.getInt("LocationCode2"));	
		   					orderVm.setPersonCode(rs.getInt("personCode"));
		   					orderVm.setMemoType(rs.getString("memoType"));
		   					orderVm.setDocumentSeries((rs.getString("series")));
		   					orderVm.setDocumentMasterCode(rs.getInt("documentMasterCode"));	
		   					//orderVm.setDocumentMasterCodeForNextTransaction4(rs.getInt("documentMasterCodeForNextTransaction4"));
		   					orderDetailsResult.put("ownCode", orderVm.getOwnCode());
		   					orderDetailsResult.put("docDate", orderVm.getDocDate());
		   					orderDetailsResult.put("schemeCode", orderVm.getSchemeCode());	
		   					orderDetailsResult.put("AdvanceAmount", orderVm.getAdvanceAmount());
		   					orderDetailsResult.put("setRefDocOwnCode", orderVm.getRefDocOwnCode());
		   					orderDetailsResult.put("LocationCode2", orderVm.getLocCode2());
		   					orderDetailsResult.put("personCode", orderVm.getPersonCode());
		   					orderDetailsResult.put("memoType", orderVm.getMemoType());
		   					//orderDetailsResult.put("series", orderVm.getDocumentSeries());
		   					orderDetailsResult.put("documentMasterCode", orderVm.getDocumentMasterCode());
		   					orderDetailsResult.put("documentNo", orderVm.getDocumentNo());
		   					//orderDetailsResult.put("DbConnection", orderVm.getDbConnection());
		   					//orderDetailsResult.put("documentMasterCodeForNextTransaction4", orderVm.getDocumentMasterCodeForNextTransaction4());
     	   					//System.out.println(" PAVAN refDocOwncode >>:::: "+orderVm.getRefDocOwnCode()+"  personCode >> "+orderVm.getPersonCode());
		   				}	
		   			int installmentNo = installmentNumber(orderVm.getOwnCode(),orderVm.getAdvanceAmount());		   			
		   			orderVm.setInstallmentNo(installmentNo);		
		   			orderDetailsResult.put("installmentNo", orderVm.getInstallmentNo());
		   		}
		   catch(Exception e)
		   	{
			   // getOrderDetailsFlag = 1;
		   		throw new Exception("Error while getting order details : "+e.getMessage());		   		
		   	}
		   finally
		   {
			   
		   		con11.close();
		   }
		if (count != 0)
		{
			DocumentMasterCodeForNextTransaction4 = getRecordFromDocMasterTable(orderVm.getDocumentMasterCode());
			//System.out.println("DocumentMasterCodeForNextTransaction4 >> "+DocumentMasterCodeForNextTransaction4);
			if (DocumentMasterCodeForNextTransaction4 != 0)
			{
				Map<String, Object> docNoAndSeriesMapResult = getDocNo(DocumentMasterCodeForNextTransaction4);
				orderDetailsResult.put("documentNo",Integer.valueOf(docNoAndSeriesMapResult.get("documentNo").toString()));
				orderDetailsResult.put("series",(String) docNoAndSeriesMapResult.get("defaultSeries"));
				orderDetailsResult.put("masterCodeForNewDmnRecord",Integer.valueOf(docNoAndSeriesMapResult.get("documentMasterCode").toString()));
				//System.out.println("masterCodeForNewDmnRecord >> "+Integer.valueOf(docNoAndSeriesMapResult.get("documentMasterCode").toString()));
			}
			/*if (documentNo == 0)
			{
				String defaultSeries = getRecordFromDocMasterTable(orderVm.getDocumentMasterCodeForNextTransaction4());
				if (defaultSeries.isEmpty())
				{
					
				}
				else
				{
					dataInsertService.insertRecordIntoAutoNoTable(orderVm.getDocumentMasterCodeForNextTransaction4(), defaultSeries);
					documentNo = 1;
				}				
			}*/
			
		}
		//DataInsertService insertDataService=new DataInsertService();
		//insertDataService.insertRecordIntoAutoNoTable(orderVm.getDocumentSeries(),orderVm.getDocumentMasterCode());
		
		//System.out.println("installmentNo >> "+orderVm.getInstallmentNo());
		return orderDetailsResult;	   	
	}
	
	@Override
	public Map<String, Object> getDocNo(int documentMasterCode)
	{			
		int flag=0,documentNo=0,DocumentMasterCodeForNextTransaction4;
		String defaultSeries = null;
		GetDocNo getDocno=new GetDocNo();
		Map<String, Object> docNoAndSeriesMapResult = new LinkedHashMap<String, Object>();
		
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM AutoNoTableForDocument WHERE documentMasterCode= "+documentMasterCode+" ");//AND  series='"+orderVm.getDocumentSeries()+"'
		   
		   			while(rs.next())
		   				{		   				
		   					getDocno.setDocumentNo(rs.getInt("DocNo"));		   					
		   					getDocno.setSeriesFromAutoNoTable(rs.getString("Series"));
		   					defaultSeries = getDocno.getSeriesFromAutoNoTable();
		   					//docMasterCode          =  rs.getInt("DocumentMasterCode");
		   					documentNo = getDocno.getDocumentNo();		   								
		   					documentNo += 1;		   					
		   					docNoAndSeriesMapResult.put("documentNo", documentNo);
		   					docNoAndSeriesMapResult.put("defaultSeries", defaultSeries);		   		
		   					flag=1;
		   					
		   					//System.out.println("****getDocNo >> documentNo : "+getDocno.getDocumentNo()+"  seriesFromAutoNoTable : "+getDocno.getSeriesFromAutoNoTable());
		   				}		   
		   			if (flag != 1)
		   			{
		   				defaultSeries = getSeriesFromDocMasterTable(documentMasterCode);
		   				DataInsertService insertDataService=new DataInsertService();
		   				insertDataService.insertRecordIntoAutoNoTable(defaultSeries, documentMasterCode);
		   				documentNo = 1;
		   				//insertRecordIntoAutoNoTable();
	   					docNoAndSeriesMapResult.put("documentNo", documentNo);
	   					docNoAndSeriesMapResult.put("defaultSeries", defaultSeries);  					
		   				//System.out.println("Doc No Inserted...");		   				
		   			}
		   			else
		   			{
					       //UpdateTableData updateService=new UpdateTableData();
					       //updateService.updateAutoNoTableForDoc(documentNo,documentMasterCode);

		   			}
		   			//DataInsertService insertDataService=new DataInsertService();
		   			//insertDataService.insertRecordIntoAutoNoTable(getDocno.getSeriesFromAutoNoTable(),documentMasterCode);
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting Doc No from AutoNoTable : "+e);
		   	} 
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		docNoAndSeriesMapResult.put("documentMasterCode",documentMasterCode);
		return docNoAndSeriesMapResult;

	}
	
	@Override
	public int getDateTime(String date1)
	{		
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT DATEDIFF('"+date1+"', DATE('18001228')) as Date");
			   
		   			while(rs.next())
		   				{
		   					date   =  rs.getInt("Date");     		   				
		   					//System.out.println("date : "+date);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while calculating today's date : "+e);
		   		date = 0;
		   	}     
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return date;
	}
	
	@Override
	public int getOwnCodeForDMN() throws ClassNotFoundException, SQLException
	{
		int ownCode=0;
		Connection con11=null;
			try
			{				
			   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
     		  //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
				Connection con = databaseConnectionService.databaseConnectionMethod();
				Class.forName("com.mysql.jdbc.Driver");
			       
			       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

			   java.sql.Statement stmt1=con11.createStatement();			
			   ResultSet rs;    	   
			   rs=stmt1.executeQuery(" SELECT * FROM AutoNoTable WHERE series='a'");			   
			   			while(rs.next())
			   				{
			   					ownCode   =  rs.getInt("owncode");	      
			   					ownCode  += 1;
			   					//System.out.println("OwnCode : "+ownCode);
			   				}   					   		
			   		}
			   	catch(Exception e)
			   	{
			   		System.out.println("Error while getting OwnCode : "+e);
			   	}   
			finally
			{
				con11.close();
			}
			return ownCode;
	}

	@Override
	public int getOwnCodeForAccountsTable() throws ClassNotFoundException, SQLException
	{
		int ownCodeForAccTable=0;
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
			try
			{				
			   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
			   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
				Class.forName("com.mysql.jdbc.Driver");
			       
			       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

			   java.sql.Statement stmt1=con11.createStatement();			
			   ResultSet rs;    	   
			   rs=stmt1.executeQuery(" SELECT * FROM AutoNoTable WHERE series='DPay'");			   
			   			while(rs.next())
			   				{
			   					ownCodeForAccTable   =  rs.getInt("owncode");	      
			   					ownCodeForAccTable  += 1;
			   					//System.out.println("ownCodeForAccTable : "+ownCodeForAccTable);
			   				}   					   		
			   		}
			   	catch(Exception e)
			   	{
			   		System.out.println("Error while getting OwnCode : "+e);
			   	}    
			finally
			{
				con11.close();
			}
			return ownCodeForAccTable;
	}

	@Override
	public int getTodaysRate(int date)
	{
		int saleRate=0;
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{
			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   Class.forName("com.mysql.jdbc.Driver");
		       
		   con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();
		   java.sql.Statement stmt2=con11.createStatement();
		   ResultSet rs,rs2;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DailyRatesTable WHERE docDate = "+date+" AND MetalType = 1");	
		   
		   			while(rs.next())
		   				{
		   					saleRate   =  rs.getInt("ownCode");  
		   					//System.out.println("saleRate >> "+saleRate);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting todays rate : "+e);
		   	}
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return saleRate;
	}

	@Override
	public void getSchemeDetails(String ownCode) 
	{
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		 
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT a.OwnCode,b.FieldValue,c.FieldValue,d.FieldValue FROM DocumentMainTable a  JOIN  SecondaryMasterDetails b ON a.CompCode = b.CompCode AND a.adjustmentmethod = b.MasterCode AND b.MasterType = 60 AND b.FieldNo = 80 JOIN  SecondaryMasterDetails c ON a.CompCode = c.CompCode AND a.adjustmentmethod = c.MasterCode AND c.MasterType = 60 AND c.FieldNo = 90   JOIN  SecondaryMasterDetails d ON a.CompCode = d.CompCode AND a.adjustmentmethod = d.MasterCode AND d.MasterType = 60 AND d.FieldNo = 150   WHERE a.compcode=1 AND a.owncode = "+ownCode+"");	
		   
		   			while(rs.next())
		   				{
		   					//schemeVm.setMinInstammentAmt("b.FieldValue");
		   					//System.out.println("saleRate >> "+saleRate);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting scheme details rate : "+e);
		   	}
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public int getRecordFromDocMasterTable(int documentmasterCode)
	{
	    String defaultSeries = null;
	    int count = 0,DocumentMasterCodeForNextTransaction4 = 0;
	    Connection con = databaseConnectionService.databaseConnectionMethod();
	    Connection con11=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
	
		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMaster WHERE documentmasterCode="+documentmasterCode+"");
		   
		   			while(rs.next())
		   				{		
		   					count = 0;
		   					DocumentMasterCodeForNextTransaction4  =  rs.getInt("DocumentMasterCodeForNextTransaction4");
		   					//System.out.println("defaultSeries : "+defaultSeries);
		   				}		   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting records from DocumentMasterTable : "+e);
		   	}   
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (count != 0)
		{
			//getDocNo(documentmasterCode);
		}
		return DocumentMasterCodeForNextTransaction4;
	}
	
	public String getSeriesFromDocMasterTable(int documentmasterCode) throws SQLException
	{
	    String defaultSeries = null;
	    Connection con = databaseConnectionService.databaseConnectionMethod();
	    int count = 0;
	    Connection con11=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
	
		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMaster WHERE documentmasterCode="+documentmasterCode+"");
		   
		   			while(rs.next())
		   				{		
		   					count = 0;
		   					defaultSeries  =  rs.getString("defaultSeries");
		   					//System.out.println("defaultSeries : "+defaultSeries);
		   				}		   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting records from DocumentMasterTable : "+e);
		   	}   
		finally
		{
			con11.close();
		}
		
		if (count != 0)
		{
			getDocNo(documentmasterCode);
		}
		return defaultSeries;
	}

	@Override
	public int installmentNumber(int ownCode,int amount) throws SQLException
	{
	    
	    int advanceAmount,installmentNo = 0;
	    //Connection con = databaseConnectionService.databaseConnectionMethod();
	    Connection con11=null;
		try
		{
		   Class.forName("com.mysql.jdbc.Driver");		     
		   con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT SUM(AdvanceAmount) FROM DocumentMainTable WHERE CompCode=1 AND owncode = "+ownCode+" OR refDocOwnCode="+ownCode+"");
		   
		   			while(rs.next())
		   				{				   				
		   					advanceAmount  =  rs.getInt("SUM(AdvanceAmount)");
		   					installmentNo  = (int)advanceAmount/amount;
		   					//System.out.println("advanceAmount : "+advanceAmount+"  amount >> "+amount);
		   				}		   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while calculating installment number : "+e);
		   	}  
		finally
		{
			con11.close();
		}
		return installmentNo;
	}
	
	@Override
	public String getDdMmYyDate(int docDate)
	{		
		//Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		int date1=0;
		String date=null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   Class.forName("com.mysql.jdbc.Driver");		       
		   con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT DATE_FORMAT(DATE_ADD('1800-12-28', INTERVAL "+docDate+" DAY) ,'%d/%m/%Y') as Date");
			   
		   			while(rs.next())
		   				{
		   					date   =  rs.getString("Date");    
		   					//date = String.valueOf(date1);
		   					//System.out.println("date : "+date);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while getting MM/MM/YY date : "+e);
		   		//date = 0;
		   	}     
		finally
		{
			try 
			{
				con11.close();
			} 
			catch (SQLException e) 
			{			
				e.printStackTrace();
			}
		}
		//System.out.println("Date >> " +date);
		return date;
	}

	@Override
	public int getNoOfMonths(int schemeCode) throws ClassNotFoundException, SQLException
	{
	       int noOfMonths = 0;
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("select * from SecondaryMasterDetails where Compcode=1 AND Mastertype=60 and MasterCode = "+schemeCode+" and fieldno=20");
		   try
		   {
			while(rs.next())
         	 {
				noOfMonths = rs.getInt("fieldValue");				
         	 }			
		   }
		   catch(Exception e)
		   {
			   System.out.println("Error while getting number of months : "+e);
		   }
		   con11.close();
		   return noOfMonths;
	}

	@Override
	public Map<String, Object> allowVariableInstallmntAmount(int schemeCode) throws ClassNotFoundException, SQLException
	{
  		   Map<String, Object> allowVariableInstallmntAmountMapResult = new LinkedHashMap<String, Object>();
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT a.FieldValue AS variableInstallmnt ,b.Fieldvalue AS amountMultipleOf,c.Fieldvalue AS minAmount FROM SecondaryMasterDetails  a JOIN SecondaryMasterDetails b ON a.compCode= b.CompCode AND a.MasterType=b.masterType AND a.masterCode= b.MasterCode AND b.Fieldno= 90 JOIN SecondaryMasterDetails c ON a.compCode= c.CompCode AND a.MasterType=c.masterType AND a.masterCode= c.MasterCode AND c.Fieldno= 80  WHERE a.Compcode=1 AND a.Mastertype=60 AND a.MasterCode = "+schemeCode+" AND a.fieldno=140");
		   try
		   {
			while(rs.next())
         	 {	
				allowVariableInstallmntAmountMapResult.put("variableInstallmnt", rs.getString("variableInstallmnt"));
				allowVariableInstallmntAmountMapResult.put("amountMultipleOf", rs.getInt("amountMultipleOf"));
				allowVariableInstallmntAmountMapResult.put("minAmount", rs.getInt("minAmount"));
				
         	 }			
		   }
		   catch(Exception e)
		   {
			   System.out.println("Error while getting variable installment amount : "+e);
		   }
		   con11.close();
		   return allowVariableInstallmntAmountMapResult;
	}
	
	@Override
	public int getInstallmentCount(int refDocNo) throws ClassNotFoundException, SQLException
	{
		   int installmentCount = 0;  		
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT COUNT(ownCode) FROM DocumentMainTable WHERE CompCode=1 AND RefDocOwnCode= "+refDocNo+"");
		   try
		   {
			while(rs.next())
         	 {
				installmentCount = rs.getInt("COUNT(ownCode)");
         	 }			
		   }
		   catch(Exception e)
		   {
			   System.out.println("Error while getting installment count : "+e);
		   }
		   con11.close();
		   return installmentCount+1;
	}	

	@Override
	public int getUser() throws ClassNotFoundException, SQLException
	{
	       int userCode = 0;
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT fieldValue as userCode FROM PrimeMasterDetails WHERE compcode=1 AND mastertype=2 AND fieldno=6270");
		   try
		   {
			while(rs.next())
         	 {
				userCode = rs.getInt("userCode");				
         	 }			
		   }
		   catch(Exception e)
		   {
			   System.out.println("Error while getting user Code : "+e);
		   }
		   con11.close();
		   return userCode;
	}
	
	@Override
	public int getMaturitydate(int ownCode) throws ClassNotFoundException, SQLException, ParseException
	{
	       int maturityDate = 0;
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT * FROM DocumentMainTable WHERE CompCode=1  AND OwnCode = "+ownCode+"");
		   try
		   {
			while(rs.next())
         	 {
				maturityDate = rs.getInt("DueDate");				
         	 }			
		   }
		   catch(Exception e)
		   {
			     System.out.println("Error while getting maturity date : "+e);	   		    	 
		   }
		    con11.close();
			
		   return maturityDate;
	}	
	
	@Override
	public String dateConversionforClarion(String date)
	{		
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		String date1= null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT DATE_FORMAT(STR_TO_DATE('"+date+"', '%d/%m/%Y'), '%Y/%m/%d') as date");
			   
		   			while(rs.next())
		   				{
		   					date1   =  rs.getString("Date");     		   				
		   					//System.out.println("date : "+date);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while converting date : "+e);
		   		date1 = null;
		   	}     
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return date1;
	}

	@Override
	public int todaysGetDateTime()
	{		
		Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT DATEDIFF(DATE(NOW()), DATE('18001228')) AS DATE");
			   
		   			while(rs.next())
		   				{
		   					date   =  rs.getInt("Date");     		   				
		   					//System.out.println("date : "+date);
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while calculating today's date : "+e);
		   		date = 0;
		   	}     
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return date;
	}
	
	@Override
	public long getClarionTime()
	{		
		//Connection con = databaseConnectionService.databaseConnectionMethod();
		Connection con11=null;
		long clarionTime = 0;
		try
		{			
		   //Class.forName("com.mysql.jdbc.Driver");		     			 			   
		   //con = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
			Class.forName("com.mysql.jdbc.Driver");
		       
		       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");

		   java.sql.Statement stmt1=con11.createStatement();		   
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT  ((HOUR(NOW()) * 60 *60 + (MINUTE(NOW())*60) + SECOND(NOW())) * 100) AS TIME");
			   
		   			while(rs.next())
		   				{
		   					clarionTime   =  rs.getInt("TIME");     		   						   			
		   				}		   				   		
		   		}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error while calculating current date : "+e);
		   		clarionTime = 0;
		   	}     
		finally
		{
			try {
				con11.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return clarionTime;
	}
	
	@Override
	public BigDecimal getInstallmentAmount(int refDocNo) throws ClassNotFoundException, SQLException
	{
		   BigDecimal totalInstallmentAmount = null;  		
		   Class.forName("com.mysql.jdbc.Driver");
	       Connection con11=null;
	       con11 = DriverManager.getConnection("jdbc:mysql://172.16.2.216:3306/JBsaraf_5may","AcmeInfi","ProteasLankans");
		   java.sql.Statement stmt1=con11.createStatement();		
		   ResultSet rs;    	    
		   rs=stmt1.executeQuery("SELECT SUM(AdvanceAmount) FROM DocumentMainTable WHERE compcode =1 AND ownCode= "+refDocNo+" OR refDocOwnCode = "+refDocNo+"");
		   try
		   {
			while(rs.next())
         	 {
				totalInstallmentAmount = rs.getBigDecimal("SUM(AdvanceAmount)");
         	 }			
		   }
		   catch(Exception e)
		   {
			   System.out.println("Error while getting installment count : "+e);
		   }
		   con11.close();
		   return totalInstallmentAmount;
	}	

	
}


